package com.carquick.android;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

final class Config {
 static final class Entry {
  String id, category, title, message;
  Entry(String category,String title,String message){this(UUID.randomUUID().toString(),category,title,message);}
  Entry(String id,String category,String title,String message){this.id=id;this.category=category;this.title=title;this.message=message;}
 }
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("config",0);}
 static List<Entry> entries(Context c){
  List<Entry> out=new ArrayList<>();String json=prefs(c).getString("entriesV2",null);
  if(json!=null){try{JSONArray a=new JSONArray(json);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new Entry(o.getString("id"),o.getString("category"),o.getString("title"),o.getString("message")));}return out;}catch(Exception ignored){}}
  String old=prefs(c).getString("shortcuts","");
  if(!old.isEmpty())for(String s:old.split("\\n")){int i=s.indexOf('|');if(i>0&&!s.substring(i+1).trim().isEmpty())out.add(new Entry(s.substring(0,i),s.substring(i+1),s.substring(i+1)));}
  if(out.isEmpty()){
   for(String min:new String[]{"5分","10分","準時"})out.add(new Entry("跑車",min,"9205／深藍／"+min));
   for(String min:new String[]{"20分","25分","30分"})out.add(new Entry("長單",min,"9205／深藍／"+min));
   out.add(new Entry("未見","未見乘客","已到，尚未見到乘客"));
  }
  String previousCar=prefs(c).getString("car","").trim();
  if(!previousCar.isEmpty()&&out.stream().noneMatch(e->e.message.equals(previousCar))){Entry custom=new Entry("跑車","我的車訊",previousCar);out.add(0,custom);active(c,custom);}
  save(c,out);return out;
 }
 static void save(Context c,List<Entry> entries){
  JSONArray a=new JSONArray();for(Entry e:entries)try{JSONObject o=new JSONObject();o.put("id",e.id);o.put("category",e.category);o.put("title",e.title);o.put("message",e.message);a.put(o);}catch(Exception ignored){}
  prefs(c).edit().putString("entriesV2",a.toString()).apply();
 }
 static List<String> categories(Context c){List<String> out=new ArrayList<>();try{JSONArray a=new JSONArray(prefs(c).getString("categoriesV2","[\"跑車\",\"長單\",\"未見\"]"));for(int i=0;i<a.length();i++)if(!out.contains(a.getString(i)))out.add(a.getString(i));}catch(Exception ignored){}
  for(Entry e:entries(c))if(!out.contains(e.category))out.add(e.category);return out;
 }
 static void saveCategories(Context c,List<String> categories){prefs(c).edit().putString("categoriesV2",new JSONArray(categories).toString()).apply();}
 static Entry active(Context c){List<Entry> all=entries(c);String id=prefs(c).getString("activeEntry","");for(Entry e:all)if(e.id.equals(id))return e;return all.isEmpty()?null:all.get(0);}
 static void active(Context c,Entry e){prefs(c).edit().putString("activeEntry",e.id).apply();}
 static final class FloatingButton {
  String id,title,message;boolean append;
  FloatingButton(String id,String title,String message,boolean append){this.id=id;this.title=title;this.message=message;this.append=append;}
  Entry entry(){return new Entry(id,"懸浮按鈕",title,message);}
 }
 static int floatingCount(Context c){return FloatingSpec.count(prefs(c).getInt("floatingCount",FloatingSpec.DEFAULT_COUNT));}
 static List<FloatingButton> allFloating(Context c){
  List<FloatingButton> out=new ArrayList<>();String raw=prefs(c).getString("floatingSlots",null);
  if(raw!=null)try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new FloatingButton(o.getString("id"),o.getString("title"),o.getString("message"),o.optBoolean("append",true)));}}catch(Exception ignored){}
  if(raw==null){for(Entry e:entries(c))out.add(new FloatingButton(UUID.randomUUID().toString(),e.title,e.message,true));}
  int count=floatingCount(c);while(out.size()<count)out.add(new FloatingButton(UUID.randomUUID().toString(),"按鈕"+(out.size()+1),"",true));
  if(raw==null)saveFloating(c,out);return out;
 }
 static List<FloatingButton> floating(Context c){List<FloatingButton> all=allFloating(c);return new ArrayList<>(all.subList(0,Math.min(floatingCount(c),all.size())));}
 static void saveFloating(Context c,List<FloatingButton> all){JSONArray a=new JSONArray();for(FloatingButton e:all)try{JSONObject o=new JSONObject();o.put("id",e.id);o.put("title",e.title);o.put("message",e.message);o.put("append",e.append);a.put(o);}catch(Exception ignored){}prefs(c).edit().putString("floatingSlots",a.toString()).apply();}
 static void floatingCount(Context c,int count){prefs(c).edit().putInt("floatingCount",FloatingSpec.count(count)).apply();saveFloating(c,allFloating(c));}
 static int floatingSize(Context c){return FloatingSpec.size(prefs(c).getInt("floatingSize",36));}
 static int floatingOpacity(Context c){return FloatingSpec.opacity(prefs(c).getInt("floatingOpacity",55));}
 static int floatingColumns(Context c){return FloatingSpec.columns(prefs(c).getInt("floatingColumns",2));}
 static boolean floatingUndo(Context c){return prefs(c).getBoolean("floatingUndo",true);}

}
