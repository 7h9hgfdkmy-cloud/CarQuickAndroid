package com.carquick.android;
import android.content.Context;
import android.graphics.*;
import android.text.TextPaint;
import android.view.View;
final class PickOverlay extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final TextPaint text=new TextPaint(Paint.ANTI_ALIAS_FLAG);
 private MessageDetector.Box box;private String preview="長按選取模式：拖到訊息，放開後送出";private final float density;
 PickOverlay(Context c){super(c);density=c.getResources().getDisplayMetrics().density;text.setTextSize(14*density);text.setColor(Color.WHITE);}
 void show(MessageDetector.Result r,boolean navigation){box=MessagePick.bounds(r);preview=r==null?"拖到訊息文字上；放開空白處取消":(navigation?"放開後導航：":"放開後加車訊傳送：")+r.text.replace('\n',' ');invalidate();}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);if(box!=null){int[] origin=new int[2];getLocationOnScreen(origin);RectF rect=new RectF(box.left-origin[0]-5*density,box.top-origin[1]-5*density,box.right-origin[0]+5*density,box.bottom-origin[1]+5*density);paint.setColor(Color.argb(42,47,175,123));paint.setStyle(Paint.Style.FILL);canvas.drawRoundRect(rect,8*density,8*density,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2*density);paint.setColor(Color.rgb(39,179,115));canvas.drawRoundRect(rect,8*density,8*density,paint);}
  paint.setStyle(Paint.Style.FILL);paint.setColor(Color.argb(235,37,38,48));RectF banner=new RectF(12*density,36*density,getWidth()-12*density,112*density);canvas.drawRoundRect(banner,12*density,12*density,paint);
  String first=preview;float width=getWidth()-48*density;int count=text.breakText(first,true,width,null);canvas.drawText(first.substring(0,count),24*density,65*density,text);if(count<first.length()){String rest=first.substring(count);int second=text.breakText(rest,true,width,null);canvas.drawText(rest.substring(0,second),24*density,91*density,text);}
 }
}
