package com.carquick.android;
import java.util.*;
import java.util.regex.*;
import java.text.Normalizer;
/** Address extraction plus separate, selectable place-name candidates for Maps. */
final class AddressExtractor {
 private static final String CITY="(?:(?:臺|台)北市|新北市|(?:臺|台)中市|(?:臺|台)南市|高雄市|桃園市|基隆市|新竹[縣市]|嘉義[縣市]|苗栗縣|彰化縣|南投縣|雲林縣|屏東縣|宜蘭縣|花蓮縣|(?:臺|台)東縣|澎湖縣|金門縣|連江縣)";
 private static final String DISTRICT="[\\p{IsHan}]{1,5}?(?:區|鄉|鎮|市)";
 private static final String STREET="[\\p{IsHan}A-Za-z0-9]{1,28}?(?:大道|路|街)(?:[0-9一二三四五六七八九十百]+段)?(?:[0-9一二三四五六七八九十百]+巷)?(?:[0-9一二三四五六七八九十百]+弄)?[0-9]+(?:[-之][0-9]+)?號(?:之[0-9]+)?";
 private static final Pattern ADDRESS=Pattern.compile("(?:(?:[0-9]{3,6})?(?:"+CITY+"(?:"+DISTRICT+")?|"+DISTRICT+"))?"+STREET);
 static List<String> extract(String raw){
  String normalized=Normalizer.normalize(raw,Normalizer.Form.NFKC).replace("臺灣","").replace("台灣","");
  String[] original=normalized.split("\\n");List<String> lines=new ArrayList<>();
  for(String line:original){String s=line.trim();if(s.matches("^(備註|备注|車訊|车讯|電話|电话|聯絡|联系)[:：].*")||s.matches("^(?:(?:上午|下午|AM|PM)\\s*)?[0-9]{1,2}:[0-9]{2}(?:\\s*(?:AM|PM))?$")||s.matches("^[0-9]{4}/.*$")){lines.add(";");continue;}s=s.replaceFirst("^(上車(?:地點|地址)?|下車(?:地點|地址)?|上|下|地址|地點|起點|終點)\\s*[:：]\\s*","");lines.add(s);}
  // Join wrapped lines only inside a paragraph; punctuation remains a boundary.
  String text=String.join("\n",lines).replaceAll("([\\p{IsHan}0-9])[ \\t]*\\n[ \\t]*([\\p{IsHan}0-9])","$1$2");
  text=text.replaceAll("[ \\t]+","");LinkedHashSet<String> found=new LinkedHashSet<>();Matcher m=ADDRESS.matcher(text);while(m.find()){String address=m.group();address=address.replaceFirst("^[0-9]{3,6}(?=(?:"+CITY+"|"+DISTRICT+"))","");found.add(address);}return new ArrayList<>(found);
 }
 // Place names cannot be verified offline. Keep each line separate so a multi-line
 // conversation is never silently used as one destination; Maps resolves the name.
 static List<String> placeCandidates(String raw){
  LinkedHashSet<String> labeled=new LinkedHashSet<>(),plain=new LinkedHashSet<>();
  if(raw==null)return new ArrayList<>();
  for(String line:Normalizer.normalize(raw,Normalizer.Form.NFKC).split("\\n")){
   String value=line.trim();
   if(value.isEmpty()||value.matches("^(備註|备注|車訊|车讯|電話|电话|聯絡|联系)[:：].*")||value.matches("^[0-9]{4}/.*$")||value.matches("^(?:(?:上午|下午|AM|PM)\\s*)?[0-9]{1,2}:[0-9]{2}(?:\\s*(?:AM|PM))?$"))continue;
   String stripped=value.replaceFirst("^(上車(?:地點|地址)?|下車(?:地點|地址)?|上|下|地址|地點|起點|終點|店名)\\s*[:：]\\s*","").trim();
   if(stripped.length()<2||stripped.length()>160||stripped.matches("^[0-9+() .-]+$")||stripped.startsWith("@")||stripped.matches("^(已到|收到|好的|謝謝|谢谢|未見|未见|OK|ok)[，,。!！ ]*.*"))continue;
   (stripped.equals(value)?plain:labeled).add(stripped);
  }
  return new ArrayList<>(labeled.isEmpty()?plain:labeled);
 }
 static String withCity(String destination,String city){if(city==null||city.trim().isEmpty()||Pattern.compile(CITY).matcher(destination).find())return destination;return city.trim()+destination;}
}
