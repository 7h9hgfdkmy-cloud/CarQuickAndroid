package com.carquick.android;
/** Selects only a visible message bubble, not a sender name, timestamp, or blank row. */
final class MessagePick {
 static MessageDetector.Box bounds(MessageDetector.Result result){
  if(result==null||result.body==null)return null;MessageDetector.Box b=result.body.box;int l=b.left,t=b.top,r=b.right,bt=b.bottom;
  for(MessageDetector.Node n:MessageDetector.flatten(result.row))if(n.visible&&!n.editable&&!MessageDetector.metadataId(n.id)&&!result.body.id.isEmpty()&&result.body.id.equals(n.id)&&Math.abs(n.box.left-b.left)<Math.max(16,result.row.box.width()/12)){l=Math.min(l,n.box.left);t=Math.min(t,n.box.top);r=Math.max(r,n.box.right);bt=Math.max(bt,n.box.bottom);}
  return new MessageDetector.Box(l,t,r,bt);
 }
 static MessageDetector.Result at(MessageDetector.Node root,float x,float y,int padding){
  if(root==null)return null;MessageDetector.Result best=null;long distance=Long.MAX_VALUE;
  for(MessageDetector.Node row:MessageDetector.rows(root)){
   if(y<row.box.top||y>row.box.bottom||MessageDetector.onlySeparator(row))continue;
   MessageDetector.Result result=MessageDetector.parse(row);if(!result.readable())continue;MessageDetector.Box b=bounds(result);
   if(x<b.left-padding||x>b.right+padding||y<b.top-padding||y>b.bottom+padding)continue;
   long dx=Math.round(x-b.cx()),dy=Math.round(y-b.cy()),d=dx*dx+dy*dy;if(d<distance){best=result;distance=d;}else if(d==distance)best=null;
  }return best;
 }
}
