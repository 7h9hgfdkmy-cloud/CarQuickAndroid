package com.carquick.android;

/** Shared UI ranges and touch classification, independent of Android. */
final class FloatingSpec {
 static final int DEFAULT_COUNT=5,MAX_COUNT=20;
 static int count(int value){return clamp(value,1,MAX_COUNT);}
 static int size(int value){return clamp(value,28,60);}
 static int opacity(int value){return clamp(value,20,100);}
 static int columns(int value){return clamp(value,1,4);}
 static int width(int size){return Math.round(size(size)*1.85f);}
 static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
 static boolean moved(float dx,float dy,int threshold){return dx*dx+dy*dy>(float)threshold*threshold;}
}
