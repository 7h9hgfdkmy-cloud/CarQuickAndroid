package com.carquick.android;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
final class LicenseSignature {
 static String payload(String jwt,String publicKey)throws GeneralSecurityException{
  String[] parts=jwt.split("\\.",-1);if(parts.length!=3)throw new GeneralSecurityException("會員憑證格式錯誤");
  try{PublicKey key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKey)));Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(key);verifier.update((parts[0]+"."+parts[1]).getBytes(StandardCharsets.US_ASCII));if(!verifier.verify(Base64.getUrlDecoder().decode(parts[2])))throw new GeneralSecurityException("會員憑證無法驗證");return new String(Base64.getUrlDecoder().decode(parts[1]),StandardCharsets.UTF_8);}catch(IllegalArgumentException e){throw new GeneralSecurityException("會員憑證格式錯誤",e);}
 }
}
