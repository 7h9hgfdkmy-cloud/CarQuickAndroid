package com.carquick.android;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;
final class UiTree {
 static MessageDetector.Node read(AccessibilityNodeInfo a){return read(a,0,new int[]{0});}
 static MessageDetector.Node read(AccessibilityNodeInfo a,int depth,int[] count){if(a==null||depth>45||count[0]++>2500)return null;
  MessageDetector.Node n=new MessageDetector.Node();n.handle=a;n.id=str(a.getViewIdResourceName());n.text=str(a.getText());n.description=str(a.getContentDescription());n.kind=str(a.getClassName());n.visible=a.isVisibleToUser();n.editable=a.isEditable();n.hint=Build.VERSION.SDK_INT>=26&&a.isShowingHintText();n.clickable=a.isClickable();n.longClickable=a.isLongClickable();n.scrollable=a.isScrollable();Rect r=new Rect();a.getBoundsInScreen(r);n.box=new MessageDetector.Box(r.left,r.top,r.right,r.bottom);
  for(int i=0;i<a.getChildCount();i++){MessageDetector.Node c=read(a.getChild(i),depth+1,count);if(c!=null)n.add(c);}if(n.text.isEmpty()&&!n.description.isEmpty()&&!MessageDetector.metadataId(n.id)&&(MessageDetector.bodyId(n.id)||(n.kind.endsWith("TextView")&&n.children.isEmpty())))n.text=n.description;return n;
 }
 static String str(CharSequence x){return x==null?"":x.toString();}
 static AccessibilityNodeInfo handle(MessageDetector.Node n){return n==null?null:(AccessibilityNodeInfo)n.handle;}
}
