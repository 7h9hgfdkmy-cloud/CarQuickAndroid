package com.carquick.android;
/** Lease checks use monotonic elapsed time, not the user's adjustable wall clock. */
final class LeaseClock {
 private volatile long until;
 synchronized boolean grant(long nowElapsed,long issued,long expires,boolean active){
  long seconds=expires-issued;
  if(!active||issued<=0||seconds<=0||seconds>300){until=0;return false;}
  until=nowElapsed+seconds*1000;return true;
 }
 boolean valid(long nowElapsed){return until>nowElapsed;}
 long remaining(long nowElapsed){return Math.max(0,until-nowElapsed);}
 synchronized void clear(){until=0;}
}
