package com.carquick.android;

/** Keeps a LINE overlay steady while Android temporarily has no readable app window. */
final class OverlayVisibility {
 enum Foreground { LINE, OTHER, UNKNOWN }
 static final long TRANSITION_GRACE_MS=1200;
 private boolean visible;
 private long unknownSince=-1;
 boolean update(Foreground app,long now){
  if(app==Foreground.LINE){visible=true;unknownSince=-1;}
  else if(app==Foreground.OTHER){visible=false;unknownSince=-1;}
  else if(visible){if(unknownSince<0)unknownSince=now;if(now-unknownSince>=TRANSITION_GRACE_MS)visible=false;}
  return visible;
 }
 boolean waiting(){return visible&&unknownSince>=0;}
}
