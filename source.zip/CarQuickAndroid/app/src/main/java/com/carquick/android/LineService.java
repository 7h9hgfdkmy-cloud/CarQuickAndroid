package com.carquick.android;

import android.accessibilityservice.*;
import android.app.AlertDialog;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;

public class LineService extends AccessibilityService {
 static final String LINE="jp.naver.line.android";
 final Handler handler=new Handler(Looper.getMainLooper());
 final OverlayVisibility overlayVisibility=new OverlayVisibility();
 final Runnable visibilityCheck=()->updateVisibility();
 final Runnable memberExpiryCheck=()->updateVisibility();
 boolean contentCheckQueued=false;
 final Runnable contentCheck=()->{contentCheckQueued=false;updateVisibility();};
 WindowManager wm;DragPanel panel;WindowManager.LayoutParams position;
 boolean busy=false,capturing=false,draggingPanel=false;int generation=0,dragStartX,dragStartY;
 SharedPreferences.OnSharedPreferenceChangeListener preferenceListener;
 String pendingText="";long lastSendAt=0;
 PickOverlay pickOverlay;Config.FloatingButton pickButton;boolean picking=false,pickNavigation=false;long lastPickAt=0;int pickWindow=-1;
 @Override protected void onServiceConnected(){
  Membership.get(this);wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  panel=new DragPanel(this,new DragPanel.Listener(){
   public void moved(float dx,float dy){
    if(!draggingPanel){dragStartX=position.x;dragStartY=position.y;draggingPanel=true;}
    position.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-panel.getWidth(),dragStartX+Math.round(dx)));
    position.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-panel.getHeight(),dragStartY+Math.round(dy)));
    wm.updateViewLayout(panel,position);
   }
   public void ended(){draggingPanel=false;Config.prefs(LineService.this).edit().putInt("floatingX",position.x).putInt("floatingY",position.y).apply();}
  });
  position=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
  position.gravity=Gravity.TOP|Gravity.LEFT;position.x=Config.prefs(this).getInt("floatingX",dp(8));position.y=Config.prefs(this).getInt("floatingY",dp(180));
  rebuildPanel();wm.addView(panel,position);panel.post(this::clampPosition);updateVisibility();
  preferenceListener=(prefs,key)->{if("memberRevision".equals(key)){handler.post(()->{if(!Membership.allowed())cancel();updateVisibility();});return;}if("floatingEnabled".equals(key)){handler.post(()->{if(!Config.floatingEnabled(this))cancel();updateVisibility();});return;}if(key!=null&&(key.equals("floatingSlots")||key.equals("floatingCount")||key.equals("floatingSize")||key.equals("floatingOpacity")||key.equals("floatingColumns")||key.equals("floatingUndo")||key.equals("floatingNavigation")))handler.post(()->{if(panel==null)return;rebuildPanel();wm.updateViewLayout(panel,position);panel.post(this::clampPosition);});};
  Config.prefs(this).registerOnSharedPreferenceChangeListener(preferenceListener);
 }
 void clampPosition(){if(panel==null||draggingPanel)return;position.x=Math.max(0,Math.min(position.x,getResources().getDisplayMetrics().widthPixels-panel.getWidth()));position.y=Math.max(0,Math.min(position.y,getResources().getDisplayMetrics().heightPixels-panel.getHeight()));wm.updateViewLayout(panel,position);}
 void rebuildPanel(){
  panel.removeAllViews();panel.setPadding(dp(3),dp(3),dp(3),dp(3));
  GradientDrawable background=new GradientDrawable();background.setColor(Color.argb(90,239,246,255));background.setCornerRadius(dp(10));panel.setBackground(background);panel.setAlpha(Config.floatingOpacity(this)/100f);
  List<Config.FloatingButton> buttons=Config.floating(this);int size=Config.floatingSize(this),width=FloatingSpec.width(size);
  int maxColumns=Math.max(1,(getResources().getDisplayMetrics().widthPixels-dp(16))/dp(width+4));int columns=Math.min(Config.floatingColumns(this),maxColumns);
  int total=buttons.size()+(Config.floatingUndo(this)?1:0)+(Config.floatingNavigation(this)?1:0);int maxRows=Math.max(1,(getResources().getDisplayMetrics().heightPixels-dp(100))/dp(size+4));columns=Math.min(maxColumns,Math.max(columns,(total+maxRows-1)/maxRows));
  LinearLayout row=null;int index=0;
  for(Config.FloatingButton spec:buttons){if(index%columns==0){row=new LinearLayout(this);panel.addView(row);}Button b=compactButton(spec.title,()->startSend(spec.entry(),spec.append),size);b.setContentDescription(spec.title+"："+(spec.append?"最新訊息加車訊":"只發車訊")+"；長按可拖到指定訊息");b.setOnLongClickListener(v->{beginPick(spec,false);return true;});LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dp(width),dp(size));params.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(b,params);index++;}
  if(Config.floatingNavigation(this)){if(index%columns==0){row=new LinearLayout(this);panel.addView(row);}Button b=compactButton("導航",this::navigateLatest,size);b.setOnLongClickListener(v->{beginPick(null,true);return true;});LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dp(width),dp(size));params.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(b,params);index++;}
  if(Config.floatingUndo(this)){if(index%columns==0){row=new LinearLayout(this);panel.addView(row);}Button b=compactButton("收回",this::unsend,size);LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dp(width),dp(size));params.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(b,params);}
 }
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 Button compactButton(String label,Runnable action,int size){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(size<36?11:12);b.setTextColor(Color.rgb(16,35,65));b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(2),0,dp(2),0);b.setMaxLines(2);b.setEllipsize(android.text.TextUtils.TruncateAt.END);
  GradientDrawable shape=new GradientDrawable();shape.setColor(Color.rgb(223,235,255));shape.setCornerRadius(dp(8));shape.setStroke(dp(1),Color.rgb(147,180,235));b.setBackground(shape);b.setOnClickListener(v->{if(!draggingPanel)action.run();});return b;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){
  // Other apps' content events are irrelevant; window changes update visibility only.
  if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED){
   if(LINE.contentEquals(e.getPackageName())&&!contentCheckQueued){contentCheckQueued=true;handler.postDelayed(contentCheck,160);}
   return;
  }
  handler.removeCallbacks(contentCheck);contentCheckQueued=false;
  OverlayVisibility.Foreground app=foreground();
  if(app==OverlayVisibility.Foreground.UNKNOWN&&e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED&&LINE.contentEquals(e.getPackageName()))app=OverlayVisibility.Foreground.LINE;
  updateVisibility(app);
 }
 @Override public void onInterrupt(){cancel();}
 @Override public void onDestroy(){cancel();handler.removeCallbacksAndMessages(null);if(preferenceListener!=null)Config.prefs(this).unregisterOnSharedPreferenceChangeListener(preferenceListener);if(panel!=null){wm.removeView(panel);panel=null;}ScreenText.close();super.onDestroy();}
 void cancel(){generation++;busy=false;capturing=false;pendingText="";clearPick();}
 void updateVisibility(){updateVisibility(foreground());}
 void updateVisibility(OverlayVisibility.Foreground app){
  if(panel==null)return;if(picking&&(app==OverlayVisibility.Foreground.OTHER||!Config.floatingEnabled(this)||!Membership.allowed())){clearPick();busy=false;generation++;}handler.removeCallbacks(visibilityCheck);handler.removeCallbacks(memberExpiryCheck);
  boolean show=overlayVisibility.update(app,SystemClock.uptimeMillis(),Config.floatingEnabled(this)&&Membership.allowed());
  int target=(!Config.floatingEnabled(this)||!Membership.allowed())?View.GONE:(capturing?View.INVISIBLE:(show?View.VISIBLE:View.GONE));
  if(panel.getVisibility()!=target)panel.setVisibility(target);
  if(overlayVisibility.waiting())handler.postDelayed(visibilityCheck,100);
  if(!BuildMode.TEST_VERSION&&Membership.allowed())handler.postDelayed(memberExpiryCheck,Membership.get(this).remaining()+1);
 }
 OverlayVisibility.Foreground foreground(){
  AccessibilityWindowInfo top=null;
  for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION&&(top==null||w.getLayer()>top.getLayer()))top=w;
  AccessibilityNodeInfo root=top==null?getRootInActiveWindow():top.getRoot();
  if(root==null||root.getPackageName()==null)return OverlayVisibility.Foreground.UNKNOWN;
  CharSequence pkg=root.getPackageName();
  if(LINE.contentEquals(pkg))return OverlayVisibility.Foreground.LINE;
  // Our own overlay is not an app switch. System surfaces may obscure app roots.
  if(getPackageName().contentEquals(pkg)&&top==null)return OverlayVisibility.Foreground.UNKNOWN;
  if("com.android.systemui".contentEquals(pkg)||"android".contentEquals(pkg))return OverlayVisibility.Foreground.UNKNOWN;
  return OverlayVisibility.Foreground.OTHER;
 }
 // Use the top application window, ignoring our own accessibility overlay and IME.
 AccessibilityNodeInfo lineRoot(){
  AccessibilityWindowInfo top=null;
  for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION&&(top==null||w.getLayer()>top.getLayer()))top=w;
  if(top!=null){AccessibilityNodeInfo root=top.getRoot();return root!=null&&LINE.contentEquals(root.getPackageName())?root:null;}
  AccessibilityNodeInfo r=getRootInActiveWindow();return r!=null&&LINE.contentEquals(r.getPackageName())?r:null;
 }
 MessageDetector.Node tree(){return UiTree.read(lineRoot());}
 MessageDetector.Node composerTree(){return UiTree.composer(lineRoot());}
 void note(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
 void finish(String text){busy=false;pendingText="";note(text);}
 void startSend(Config.Entry entry,boolean append){
  if(!Membership.allowed()){note("請在 App 登入有效會員帳號");return;}
  if(!Config.floatingEnabled(this)||busy||SystemClock.uptimeMillis()-lastSendAt<Timing.TAP_GUARD_MS)return;
  if(entry==null||entry.message.trim().isEmpty()){note("請先在 App 設定此按鈕的車訊");return;}
  MessageDetector.Node t=composerTree();if(t==null||MessageDetector.editor(t)==null){note("請先開啟 LINE 聊天室");return;}
  MessageDetector.Node e=MessageDetector.editor(t);if(!empty(e)){note("LINE 輸入框已有草稿，請先清空");return;}
  busy=true;int op=++generation;
  if(!append){fill(entry.message,op);return;}
  moveToLatest(op,0,null,0,root->{
   if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}if(root==null){finish("請回到 LINE 聊天室");return;}
   MessageDetector.Result r=MessageDetector.latest(root,false);
   if(r.readable()){fill(r.text+"\n"+entry.message,op);return;}
   if(r.media){finish(r.reason+"，不會擷取前一則文字");return;}
   if(r.row!=null&&Build.VERSION.SDK_INT>=30){ocrRow(r.row,root,op,text->{if(text==null||text.trim().isEmpty()){finish("未能讀取最新文字；可將這個按鈕改為『只發車訊』");return;}fill(text+"\n"+entry.message,op);});}
   else finish("LINE 未提供可辨識的訊息；可將這個按鈕改為『只發車訊』");
  });
 }
 void beginPick(Config.FloatingButton button,boolean navigation){
  if(busy||!Config.floatingEnabled(this)||!Membership.allowed())return;
  AccessibilityNodeInfo root=lineRoot();if(root==null){note("請先開啟 LINE 聊天室");return;}
  picking=true;busy=true;pickButton=button;pickNavigation=navigation;pickWindow=root.getWindowId();lastPickAt=0;int operation=++generation;
  pickOverlay=new PickOverlay(this);WindowManager.LayoutParams overlay=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);overlay.gravity=Gravity.TOP|Gravity.LEFT;
  if(Build.VERSION.SDK_INT>=28)overlay.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
  wm.addView(pickOverlay,overlay);panel.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
  panel.beginSelection(new DragPanel.Picker(){
   public void moved(float x,float y){if(operation==generation)updatePick(x,y);}
   public void ended(float x,float y,boolean cancelled){if(operation!=generation)return;completePick(x,y,cancelled,operation);}
  });
 }
 void clearPick(){if(panel!=null)panel.cancelSelection();if(pickOverlay!=null){wm.removeView(pickOverlay);pickOverlay=null;}picking=false;pickButton=null;}
 void updatePick(float x,float y){long now=SystemClock.uptimeMillis();if(now-lastPickAt<80)return;lastPickAt=now;MessageDetector.Node root=tree();MessageDetector.Result result=root==null?null:MessagePick.at(root,x,y,dp(8));if(pickOverlay!=null)pickOverlay.show(result,pickNavigation);}
 void completePick(float x,float y,boolean cancelled,int operation){
  Config.FloatingButton chosen=pickButton;boolean navigation=pickNavigation;AccessibilityNodeInfo window=lineRoot();
  MessageDetector.Node root=window==null?null:UiTree.read(window);MessageDetector.Result result=root==null?null:MessagePick.at(root,x,y,dp(8));boolean same=window!=null&&window.getWindowId()==pickWindow;
  clearPick();if(cancelled||!same||result==null){finish("未選取訊息，已取消");return;}
  if(!Membership.allowed()){finish("會員驗證已到期");return;}
  if(navigation){navigateText(result.text,operation);return;}
  if(chosen==null||chosen.message.trim().isEmpty()){finish("請先設定這個按鈕的車訊");return;}
  fill(result.text+"\n"+chosen.message,operation);
 }
 void navigateLatest(){
  if(busy||!Config.floatingEnabled(this)||!Membership.allowed())return;
  if(lineRoot()==null){note("請先開啟 LINE 聊天室");return;}busy=true;int operation=++generation;
  moveToLatest(operation,0,null,0,root->{
   if(operation!=generation)return;if(root==null){finish("請回到 LINE 聊天室");return;}
   MessageDetector.Result result=MessageDetector.latest(root,false);
   if(result.readable()){navigateText(result.text,operation);return;}
   if(!result.media&&result.row!=null&&Build.VERSION.SDK_INT>=30){ocrRow(result.row,root,operation,text->{if(text==null||text.trim().isEmpty())finish("讀不到最新訊息的地址或店名");else navigateText(text,operation);});return;}
   finish("最新一則不是可辨識的文字訊息");
  });
 }
 void navigateText(String source,int operation){
  if(operation!=generation)return;List<String> destinations=AddressExtractor.extract(source);
  if(destinations.isEmpty())destinations=AddressExtractor.placeCandidates(source);
  if(destinations.size()==1){openMaps(destinations.get(0));return;}
  if(destinations.size()>1){final List<String> choices=destinations;AlertDialog dialog=new AlertDialog.Builder(this).setTitle("選擇要預估的地址／店名").setItems(choices.toArray(new String[0]),(d,i)->{if(operation==generation)openMaps(choices.get(i));}).setNeutralButton("自行輸入",(d,w)->{if(operation==generation)enterDestination(operation);}).setNegativeButton("取消",(d,w)->finish("已取消路線預估")).create();dialog.setOnCancelListener(d->finish("已取消路線預估"));dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY);dialog.show();return;}
  enterDestination(operation);
 }
 void enterDestination(int operation){
  EditText input=new EditText(this);input.setHint("輸入地址或店名，可加分店／地區");AlertDialog dialog=new AlertDialog.Builder(this).setTitle("輸入要預估的地點").setMessage("Google Maps 會先顯示開車路線、預估時間與公里數。店名不明確時，請加上分店或地區。").setView(input).setPositiveButton("查看路線",null).setNegativeButton("取消",(d,w)->finish("已取消路線預估")).create();dialog.setOnCancelListener(d->finish("已取消路線預估"));dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY);dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{String address=input.getText().toString().trim();if(address.isEmpty()){input.setError("請輸入地點");return;}dialog.dismiss();if(operation==generation)openMaps(address);}));dialog.show();
 }
 void openMaps(String address){
  String destination=AddressExtractor.withCity(address,Config.prefs(this).getString("navigationCity",""));
  // Directions URL without dir_action: show route choices / estimates, wait for Start.
  android.net.Uri url=android.net.Uri.parse("https://www.google.com/maps/dir/").buildUpon().appendQueryParameter("api","1").appendQueryParameter("destination",destination).appendQueryParameter("travelmode","driving").build();
  android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_VIEW,url);intent.setPackage("com.google.android.apps.maps");intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
  try{startActivity(intent);finish("已開啟 Google Maps 路線預估");}
  catch(android.content.ActivityNotFoundException e){try{startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,url).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));finish("已開啟 Google Maps 路線預估");}catch(Exception ignored){finish("無法開啟地圖，請先安裝 Google Maps");}}
  catch(Exception e){finish("無法啟動 Google Maps，請確認地圖 App 可使用");}
 }
 boolean empty(MessageDetector.Node e){return e!=null&&(e.hint||e.text.trim().isEmpty());}
 // Scroll to the end without assuming that a persistent scroll action means not at bottom.
 void moveToLatest(int op,int attempts,String previous,int repeats,Consumer<MessageDetector.Node> done){
  if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}MessageDetector.Node root=tree();if(root==null){finish("請回到 LINE 聊天室");return;}
  MessageDetector.Node list=MessageDetector.list(root);if(list==null){done.accept(root);return;}
  if(atLatestEnd(list)){done.accept(root);return;}
  String fingerprint=fingerprint(list);int same=fingerprint.equals(previous)?repeats+1:0;
  if(same>=2){done.accept(root);return;}
  if(attempts>=18){finish("尚未到最新訊息，請點 LINE 的向下箭頭後重試");return;}
  AccessibilityNodeInfo a=UiTree.handle(list);boolean scrolled=false;
  AccessibilityNodeInfo.CollectionInfo collection=a.getCollectionInfo();
  if(attempts==0&&collection!=null&&collection.getRowCount()>0){Bundle b=new Bundle();b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_ROW_INT,collection.getRowCount()-1);b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_COLUMN_INT,0);scrolled=a.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION.getId(),b);}
  if(!scrolled)scrolled=a.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
  if(!scrolled&&list.scrollable){
   Path path=new Path();int x=list.box.cx();int top=Math.max(list.box.top+dp(30),root.box.top+dp(100));int bottom=Math.min(list.box.bottom-dp(25),MessageDetector.editor(root)==null?root.box.bottom-dp(100):MessageDetector.editor(root).box.top-dp(20));
   if(bottom-top>dp(100)){path.moveTo(x,bottom);path.lineTo(x,top+Math.max(dp(30),(bottom-top)/4));GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,180)).build();
    boolean accepted=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){handler.postDelayed(()->moveToLatest(op,attempts+1,fingerprint,same,done),160);}@Override public void onCancelled(GestureDescription g){finish("無法移至最新訊息，請回 LINE 重試");}},handler);if(accepted)return;
   }
  }
  if(!scrolled){done.accept(root);return;}
  handler.postDelayed(()->moveToLatest(op,attempts+1,fingerprint,same,done),180);
 }
 boolean atLatestEnd(MessageDetector.Node list){
  AccessibilityNodeInfo a=UiTree.handle(list);AccessibilityNodeInfo.CollectionInfo collection=a.getCollectionInfo();
  if(collection!=null&&collection.getRowCount()>0){
   for(MessageDetector.Node child:list.children){if(!child.visible)continue;AccessibilityNodeInfo.CollectionItemInfo item=UiTree.handle(child).getCollectionItemInfo();
    if(item!=null&&Timing.endIndex(collection.getRowCount(),item.getRowIndex(),item.getRowSpan()))return true;
   }
  }
  // Absence of a forward action is useful only for an explicitly scrollable list.
  if(!list.scrollable)return false;
  boolean backward=false;
  for(AccessibilityNodeInfo.AccessibilityAction action:a.getActionList()){
   if(action.getId()==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD||action.getId()==AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId())return false;
   if(action.getId()==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD||action.getId()==AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.getId())backward=true;
  }
  return backward;
 }
 String fingerprint(MessageDetector.Node n){return MessageDetector.scrollFingerprint(n);}
 void fill(String text,int op){
  if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}MessageDetector.Node root=composerTree();MessageDetector.Node node=root==null?null:MessageDetector.editor(root);
  if(node==null){finish("找不到 LINE 輸入框");return;}if(!empty(node)){finish("保留 LINE 現有草稿，未覆蓋");return;}
  AccessibilityNodeInfo edit=UiTree.handle(node);edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
  Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
  pendingText=text;
  if(edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)){waitForText(op,0);return;}
  // Some LINE versions expose a field without ACTION_SET_TEXT. IME is a second route.
  if(QuickIme.putFromService(text)){waitForText(op,0);return;}
  pendingText="";finish("LINE 不接受直接輸入；請切換車訊快捷鍵盤後重試");
 }
 void waitForText(int op,int attempt){
  if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}
  MessageDetector.Node root=composerTree(),edit=root==null?null:MessageDetector.editor(root);
  if(edit!=null&&normalize(edit.text).equals(normalize(pendingText))){clickSend(op,0);return;}
  if(attempt<19){handler.postDelayed(()->waitForText(op,attempt+1),Timing.retryDelay(attempt));return;}
  finish("未確認輸入內容，停止傳送；請查看 LINE 輸入框");
 }
 String normalize(String s){return s.replace("\r\n","\n").replace("\u200B","");}
 void clickSend(int op,int attempt){
  if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}MessageDetector.Node root=composerTree(),edit=root==null?null:MessageDetector.editor(root);
  if(edit==null||!normalize(edit.text).equals(normalize(pendingText))){finish("輸入內容已變更，未傳送");return;}
  MessageDetector.Node button=findSend(root,edit);
  if(button!=null){AccessibilityNodeInfo a=UiTree.handle(button);if(a.performAction(AccessibilityNodeInfo.ACTION_CLICK)){verifySent(op,0);return;}
   gesture(button.box,80,()->verifySent(op,0),()->finish("傳送按鈕無法操作"));return;}
  if(attempt<11){handler.postDelayed(()->clickSend(op,attempt+1),Timing.retryDelay(attempt));return;}
  // Standard IME action (not newline insertion) is safer than guessed screen coordinates.
  if(Build.VERSION.SDK_INT>=30&&UiTree.handle(edit).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())){verifySent(op,0);return;}
  if(QuickIme.sendFromService()){verifySent(op,0);return;}
  finish("已填入內容，但找不到 LINE 傳送按鈕；請傳目前畫面協助修正");
 }
 MessageDetector.Node findSend(MessageDetector.Node root,MessageDetector.Node edit){
  MessageDetector.Node best=null;int high=0;for(MessageDetector.Node n:MessageDetector.flatten(root)){
   if(!n.visible||n.editable||n.box.width()<=0||n.box.height()<=0||n.box.top<edit.box.top-dp(40)||n.box.bottom>edit.box.bottom+dp(50))continue;
   String label=(n.text+" "+n.description).trim();String id=n.id.toLowerCase(Locale.ROOT);
   int score=0;if(n.text.trim().matches("(?i)(傳送|发送|發送|送出|send)(訊息|消息| message)?")||n.description.trim().matches("(?i)(傳送|发送|發送|送出|send)(訊息|消息| message)?"))score=100;
   if(id.matches(".*(send_button|sendbutton|button_send|btn_send|send_message|sendmessage).*")||id.endsWith("/send")||id.endsWith("_send"))score=90;
   // Unlabelled arrow: only a clickable control beside the editor in its toolbar.
   if(n.clickable&&n.box.cx()>edit.box.right&&Math.abs(n.box.cy()-edit.box.cy())<Math.max(dp(30),edit.box.height()/2)&&n.box.width()<root.box.width()/4)score=Math.max(score,50);
   if(score==0)continue;MessageDetector.Node target=n;for(int i=0;i<3&&!target.clickable&&target.parent!=null;i++)target=target.parent;
   if(!target.clickable||target.box.height()>dp(120))continue;
   if(score>high){best=target;high=score;}else if(score==high&&best!=null&&!best.equals(target)){best=null;}
  }return best;
 }
 void verifySent(int op,int attempt){
  if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}MessageDetector.Node root=composerTree(),edit=root==null?null:MessageDetector.editor(root);
  if(empty(edit)){lastSendAt=SystemClock.uptimeMillis();finish("已操作傳送，請確認 LINE 訊息氣泡");return;}
  if(attempt<19){handler.postDelayed(()->verifySent(op,attempt+1),Timing.retryDelay(attempt));return;}
  finish("LINE 尚未清空輸入框；未重複點擊，請確認是否送出");
 }
 void gesture(MessageDetector.Box box,int duration,Runnable ok,Runnable fail){Path p=new Path();p.moveTo(box.cx(),box.cy());GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();boolean accepted=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){ok.run();}@Override public void onCancelled(GestureDescription g){fail.run();}},handler);if(!accepted)fail.run();}
 void ocrRow(MessageDetector.Node row,MessageDetector.Node root,int op,Consumer<String> result){
  if(Build.VERSION.SDK_INT<30){result.accept(null);return;}
  capturing=true;panel.setVisibility(View.INVISIBLE);
  handler.postDelayed(()->{if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
   @Override public void onSuccess(ScreenshotResult shot){Bitmap hardware=null,copy=null;try{hardware=Bitmap.wrapHardwareBuffer(shot.getHardwareBuffer(),shot.getColorSpace());if(hardware!=null)copy=hardware.copy(Bitmap.Config.ARGB_8888,false);}finally{shot.getHardwareBuffer().close();if(hardware!=null)hardware.recycle();}capturing=false;updateVisibility();if(copy==null){result.accept(null);return;}final Bitmap image=copy;
    MessageDetector.Node edit=MessageDetector.editor(root),list=MessageDetector.list(root);int left=Math.max(0,row.box.left),top=Math.max(list==null?0:list.box.top,row.box.top),right=Math.min(image.getWidth(),row.box.right),bottom=Math.min(image.getHeight(),edit==null?row.box.bottom:Math.min(row.box.bottom,edit.box.top));
    if(right<=left||bottom<=top){image.recycle();result.accept(null);return;}
    Bitmap crop=Bitmap.createBitmap(image,left,top,right-left,bottom-top);if(crop!=image)image.recycle();
    ScreenText.read(crop,text->{if(op==generation)result.accept(text);},error->{if(op==generation)result.accept(null);});
   }
   @Override public void onFailure(int error){capturing=false;updateVisibility();result.accept(null);}
  });},100);
 }
 MessageDetector.Node exact(MessageDetector.Node root,String... labels){if(root==null)return null;MessageDetector.Node found=null;for(MessageDetector.Node n:MessageDetector.flatten(root))if(n.visible)for(String label:labels)if(label.equals(n.text.trim())||label.equals(n.description.trim())){MessageDetector.Node target=n;for(int i=0;i<3&&!target.clickable&&target.parent!=null;i++)target=target.parent;if(target.clickable){if(found!=null&&found!=target&&!Objects.equals(found.handle,target.handle))return null;found=target;}}return found;}
 void unsend(){if(!Membership.allowed()){note("請在 App 登入有效會員帳號");return;}if(!Config.floatingEnabled(this)||busy)return;busy=true;int op=++generation;moveToLatest(op,0,null,0,root->{
  if(root==null){finish("請開啟 LINE 聊天室");return;}MessageDetector.Result r=MessageDetector.latest(root,true);
  if(!r.readable()){finish(r.reason);return;}
  MessageDetector.Node target=r.body;while(target.parent!=null&&!target.longClickable&&target!=r.row)target=target.parent;
  Runnable menu=()->handler.postDelayed(()->unsendMenu(op,0,false),240);
  if(target.longClickable&&UiTree.handle(target).performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK))menu.run();else gesture(r.body.box,650,menu,()->finish("無法長按自己的訊息"));
 });}
 void unsendMenu(int op,int attempt,boolean confirmation){if(op!=generation)return;if(!Membership.allowed()){cancel();note("會員驗證已到期，請連線驗證");return;}MessageDetector.Node root=tree();MessageDetector.Node action=exact(root,"收回","收回訊息","撤回","撤回消息","Unsend");
  if(action==null){if(attempt<5){handler.postDelayed(()->unsendMenu(op,attempt+1,confirmation),160);return;}finish(confirmation?"已點收回，請確認 LINE 完成狀態":"LINE 未提供收回選項，未點擊刪除");return;}
  if(!UiTree.handle(action).performAction(AccessibilityNodeInfo.ACTION_CLICK)){finish("LINE 收回按鈕無法操作");return;}
  if(confirmation)finish("已操作收回，請確認 LINE 完成狀態");else handler.postDelayed(()->unsendMenu(op,0,true),350);
 }
}
