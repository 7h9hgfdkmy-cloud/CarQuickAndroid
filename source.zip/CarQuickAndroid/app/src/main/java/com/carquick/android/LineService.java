package com.carquick.android;

import android.accessibilityservice.*;
import android.app.AlertDialog;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;

public class LineService extends AccessibilityService {
 static final String LINE="jp.naver.line.android";
 final Handler handler=new Handler(Looper.getMainLooper());
 WindowManager wm;LinearLayout panel;WindowManager.LayoutParams position;
 Button main;TextView status;boolean busy=false,capturing=false;int generation=0;
 String pendingText="";long lastSendAt=0;
 @Override protected void onServiceConnected(){
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);panel=new LinearLayout(this);panel.setOrientation(1);
  panel.setPadding(dp(3),dp(3),dp(3),dp(3));panel.setBackgroundColor(Color.rgb(248,246,251));
  main=button("車訊",()->startSend(Config.active(this),true));panel.addView(main);
  panel.addView(button("選擇",this::choose));panel.addView(button("只發車訊",()->startSend(Config.active(this),false)));
  panel.addView(button("收回",this::unsend));
  status=new TextView(this);status.setText("↕ 拖曳");status.setTextSize(10);status.setMaxWidth(dp(90));status.setGravity(Gravity.CENTER);status.setPadding(0,dp(8),0,dp(8));panel.addView(status);
  position=new WindowManager.LayoutParams(dp(96),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
  position.gravity=Gravity.TOP|Gravity.LEFT;position.x=dp(8);position.y=dp(180);
  status.setOnTouchListener(new View.OnTouchListener(){float x,y;int ox,oy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();ox=position.x;oy=position.y;}else if(e.getAction()==MotionEvent.ACTION_MOVE){position.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-dp(96),ox+(int)(e.getRawX()-x)));position.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-dp(150),oy+(int)(e.getRawY()-y)));wm.updateViewLayout(panel,position);}return true;}});
  wm.addView(panel,position);updateVisibility();
 }
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 Button button(String label,Runnable run){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(0,dp(6),0,dp(6));b.setOnClickListener(v->run.run());return b;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){updateVisibility();}
 @Override public void onInterrupt(){cancel();}
 @Override public void onDestroy(){cancel();handler.removeCallbacksAndMessages(null);if(panel!=null)wm.removeView(panel);super.onDestroy();}
 void cancel(){generation++;busy=false;capturing=false;pendingText="";}
 void updateVisibility(){if(panel==null)return;panel.setVisibility(capturing?View.INVISIBLE:(lineRoot()==null?View.GONE:View.VISIBLE));Config.Entry e=Config.active(this);main.setText(e==null?"車訊":"車訊\n"+e.title);}
 // Use the top application window, ignoring our own accessibility overlay and IME.
 AccessibilityNodeInfo lineRoot(){
  AccessibilityWindowInfo top=null;
  for(AccessibilityWindowInfo w:getWindows())if(w.getType()==AccessibilityWindowInfo.TYPE_APPLICATION&&(top==null||w.getLayer()>top.getLayer()))top=w;
  if(top!=null){AccessibilityNodeInfo root=top.getRoot();return root!=null&&LINE.contentEquals(root.getPackageName())?root:null;}
  AccessibilityNodeInfo r=getRootInActiveWindow();return r!=null&&LINE.contentEquals(r.getPackageName())?r:null;
 }
 MessageDetector.Node tree(){return UiTree.read(lineRoot());}
 void note(String text){if(status!=null)status.setText(text+"\n↕ 拖曳");Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
 void finish(String text){busy=false;pendingText="";note(text);}
 void choose(){if(busy)return;List<Config.Entry> entries=Config.entries(this);if(entries.isEmpty()){note("請在 App 新增車訊按鈕");return;}String[] labels=new String[entries.size()];for(int i=0;i<labels.length;i++){Config.Entry e=entries.get(i);labels[i]=e.category+" · "+e.title+"\n"+e.message;}
  AlertDialog d=new AlertDialog.Builder(this).setTitle("選擇要發出的車訊").setItems(labels,(a,i)->{Config.active(this,entries.get(i));handler.postDelayed(this::updateVisibility,100);}).setNegativeButton("取消",null).create();d.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY);d.show();
 }
 void startSend(Config.Entry entry,boolean append){
  if(busy||SystemClock.uptimeMillis()-lastSendAt<900)return;
  if(entry==null||entry.message.trim().isEmpty()){note("請先新增車訊按鈕");return;}
  MessageDetector.Node t=tree();if(t==null||MessageDetector.editor(t)==null){note("請先開啟 LINE 聊天室");return;}
  MessageDetector.Node e=MessageDetector.editor(t);if(!empty(e)){note("LINE 輸入框已有草稿，請先清空");return;}
  busy=true;int op=++generation;status.setText(append?"取得最新訊息…":"輸入車訊…");
  if(!append){fill(entry.message,op);return;}
  moveToLatest(op,0,null,0,()->{
   if(op!=generation)return;MessageDetector.Node root=tree();if(root==null){finish("請回到 LINE 聊天室");return;}
   MessageDetector.Result r=MessageDetector.latest(root,false);
   if(r.readable()){fill(r.text+"\n"+entry.message,op);return;}
   if(r.media){finish(r.reason+"，不會擷取前一則文字");return;}
   if(r.row!=null&&Build.VERSION.SDK_INT>=30){ocrRow(r.row,root,op,text->{if(text==null||text.trim().isEmpty()){finish("未能讀取最新文字；可先使用『只發車訊』");return;}fill(text+"\n"+entry.message,op);});}
   else finish("LINE 未提供可辨識的訊息；可先使用『只發車訊』");
  });
 }
 boolean empty(MessageDetector.Node e){return e!=null&&(e.hint||e.text.trim().isEmpty());}
 // Scroll to the end without assuming that a persistent scroll action means not at bottom.
 void moveToLatest(int op,int attempts,String previous,int repeats,Runnable done){
  if(op!=generation)return;MessageDetector.Node root=tree();if(root==null){finish("請回到 LINE 聊天室");return;}
  MessageDetector.Node list=MessageDetector.list(root);if(list==null){done.run();return;}
  String fingerprint=fingerprint(list);int same=fingerprint.equals(previous)?repeats+1:0;
  if(same>=2){done.run();return;}
  if(attempts>=18){finish("尚未到最新訊息，請點 LINE 的向下箭頭後重試");return;}
  AccessibilityNodeInfo a=UiTree.handle(list);boolean scrolled=false;
  AccessibilityNodeInfo.CollectionInfo collection=a.getCollectionInfo();
  if(attempts==0&&collection!=null&&collection.getRowCount()>0){Bundle b=new Bundle();b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_ROW_INT,collection.getRowCount()-1);b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_COLUMN_INT,0);scrolled=a.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION.getId(),b);}
  if(!scrolled)scrolled=a.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
  if(!scrolled&&list.scrollable){
   Path path=new Path();int x=list.box.cx();int top=Math.max(list.box.top+dp(30),root.box.top+dp(100));int bottom=Math.min(list.box.bottom-dp(25),MessageDetector.editor(root)==null?root.box.bottom-dp(100):MessageDetector.editor(root).box.top-dp(20));
   if(bottom-top>dp(100)){path.moveTo(x,bottom);path.lineTo(x,top+Math.max(dp(30),(bottom-top)/4));GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,180)).build();
    boolean accepted=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){handler.postDelayed(()->moveToLatest(op,attempts+1,fingerprint,same,done),160);}@Override public void onCancelled(GestureDescription g){finish("無法移至最新訊息，請回 LINE 重試");}},handler);if(accepted)return;
   }
  }
  if(!scrolled){done.run();return;}
  handler.postDelayed(()->moveToLatest(op,attempts+1,fingerprint,same,done),180);
 }
 String fingerprint(MessageDetector.Node n){StringBuilder s=new StringBuilder();for(MessageDetector.Node x:MessageDetector.flatten(n))if(x.visible)s.append(x.id).append('|').append(x.text).append('|').append(x.box.top).append(':').append(x.box.bottom).append(';');return s.toString();}
 void fill(String text,int op){
  if(op!=generation)return;MessageDetector.Node root=tree();MessageDetector.Node node=root==null?null:MessageDetector.editor(root);
  if(node==null){finish("找不到 LINE 輸入框");return;}if(!empty(node)){finish("保留 LINE 現有草稿，未覆蓋");return;}
  AccessibilityNodeInfo edit=UiTree.handle(node);edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
  Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
  pendingText=text;
  if(edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)){waitForText(op,0);return;}
  // Some LINE versions expose a field without ACTION_SET_TEXT. IME is a second route.
  if(QuickIme.putFromService(text)){waitForText(op,0);return;}
  pendingText="";finish("LINE 不接受直接輸入；請切換車訊快捷鍵盤後重試");
 }
 void waitForText(int op,int attempt){
  if(op!=generation)return;handler.postDelayed(()->{
   if(op!=generation)return;MessageDetector.Node root=tree(),edit=root==null?null:MessageDetector.editor(root);
   if(edit!=null&&normalize(edit.text).equals(normalize(pendingText))){clickSend(op,0);return;}
   if(attempt<7){waitForText(op,attempt+1);return;}
   finish("未確認輸入內容，停止傳送；請查看 LINE 輸入框");
  },140);
 }
 String normalize(String s){return s.replace("\r\n","\n").replace("\u200B","");}
 void clickSend(int op,int attempt){
  if(op!=generation)return;MessageDetector.Node root=tree(),edit=root==null?null:MessageDetector.editor(root);
  if(edit==null||!normalize(edit.text).equals(normalize(pendingText))){finish("輸入內容已變更，未傳送");return;}
  MessageDetector.Node button=findSend(root,edit);
  if(button!=null){AccessibilityNodeInfo a=UiTree.handle(button);if(a.performAction(AccessibilityNodeInfo.ACTION_CLICK)){verifySent(op,0);return;}
   gesture(button.box,80,()->verifySent(op,0),()->finish("傳送按鈕無法操作"));return;}
  if(attempt<5){handler.postDelayed(()->clickSend(op,attempt+1),160);return;}
  // Standard IME action (not newline insertion) is safer than guessed screen coordinates.
  if(Build.VERSION.SDK_INT>=30&&UiTree.handle(edit).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())){verifySent(op,0);return;}
  if(QuickIme.sendFromService()){verifySent(op,0);return;}
  finish("已填入內容，但找不到 LINE 傳送按鈕；請傳目前畫面協助修正");
 }
 MessageDetector.Node findSend(MessageDetector.Node root,MessageDetector.Node edit){
  MessageDetector.Node best=null;int high=0;for(MessageDetector.Node n:MessageDetector.flatten(root)){
   if(!n.visible||n.editable||n.box.width()<=0||n.box.height()<=0||n.box.top<edit.box.top-dp(40)||n.box.bottom>edit.box.bottom+dp(50))continue;
   String label=(n.text+" "+n.description).trim();String id=n.id.toLowerCase(Locale.ROOT);
   int score=0;if(n.text.trim().matches("(?i)(傳送|发送|發送|送出|send)(訊息|消息| message)?")||n.description.trim().matches("(?i)(傳送|发送|發送|送出|send)(訊息|消息| message)?"))score=100;
   if(id.matches(".*(send_button|sendbutton|button_send|btn_send|send_message|sendmessage).*")||id.endsWith("/send")||id.endsWith("_send"))score=90;
   // Unlabelled arrow: only a clickable control beside the editor in its toolbar.
   if(n.clickable&&n.box.cx()>edit.box.right&&Math.abs(n.box.cy()-edit.box.cy())<Math.max(dp(30),edit.box.height()/2)&&n.box.width()<root.box.width()/4)score=Math.max(score,50);
   if(score==0)continue;MessageDetector.Node target=n;for(int i=0;i<3&&!target.clickable&&target.parent!=null;i++)target=target.parent;
   if(!target.clickable||target.box.height()>dp(120))continue;
   if(score>high){best=target;high=score;}else if(score==high&&best!=null&&!best.equals(target)){best=null;}
  }return best;
 }
 void verifySent(int op,int attempt){if(op!=generation)return;handler.postDelayed(()->{
  if(op!=generation)return;MessageDetector.Node root=tree(),edit=root==null?null:MessageDetector.editor(root);
  if(empty(edit)){lastSendAt=SystemClock.uptimeMillis();finish("已操作傳送，請確認 LINE 訊息氣泡");return;}
  if(attempt<7){verifySent(op,attempt+1);return;}
  finish("LINE 尚未清空輸入框；未重複點擊，請確認是否送出");
 },160);}
 void gesture(MessageDetector.Box box,int duration,Runnable ok,Runnable fail){Path p=new Path();p.moveTo(box.cx(),box.cy());GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();boolean accepted=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){ok.run();}@Override public void onCancelled(GestureDescription g){fail.run();}},handler);if(!accepted)fail.run();}
 void ocrRow(MessageDetector.Node row,MessageDetector.Node root,int op,Consumer<String> result){
  if(Build.VERSION.SDK_INT<30){result.accept(null);return;}
  capturing=true;panel.setVisibility(View.INVISIBLE);
  handler.postDelayed(()->{if(op!=generation)return;takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
   @Override public void onSuccess(ScreenshotResult shot){Bitmap hardware=null,copy=null;try{hardware=Bitmap.wrapHardwareBuffer(shot.getHardwareBuffer(),shot.getColorSpace());if(hardware!=null)copy=hardware.copy(Bitmap.Config.ARGB_8888,false);}finally{shot.getHardwareBuffer().close();if(hardware!=null)hardware.recycle();}capturing=false;updateVisibility();if(copy==null){result.accept(null);return;}final Bitmap image=copy;
    MessageDetector.Node edit=MessageDetector.editor(root),list=MessageDetector.list(root);int left=Math.max(0,row.box.left),top=Math.max(list==null?0:list.box.top,row.box.top),right=Math.min(image.getWidth(),row.box.right),bottom=Math.min(image.getHeight(),edit==null?row.box.bottom:Math.min(row.box.bottom,edit.box.top));
    if(right<=left||bottom<=top){image.recycle();result.accept(null);return;}
    Bitmap crop=Bitmap.createBitmap(image,left,top,right-left,bottom-top);if(crop!=image)image.recycle();
    ScreenText.read(crop,text->{if(op==generation)result.accept(text);},error->{if(op==generation)result.accept(null);});
   }
   @Override public void onFailure(int error){capturing=false;updateVisibility();result.accept(null);}
  });},100);
 }
 MessageDetector.Node exact(MessageDetector.Node root,String... labels){if(root==null)return null;MessageDetector.Node found=null;for(MessageDetector.Node n:MessageDetector.flatten(root))if(n.visible)for(String label:labels)if(label.equals(n.text.trim())||label.equals(n.description.trim())){MessageDetector.Node target=n;for(int i=0;i<3&&!target.clickable&&target.parent!=null;i++)target=target.parent;if(target.clickable){if(found!=null&&found!=target&&!Objects.equals(found.handle,target.handle))return null;found=target;}}return found;}
 void unsend(){if(busy)return;busy=true;int op=++generation;status.setText("尋找自己的最新訊息…");moveToLatest(op,0,null,0,()->{
  MessageDetector.Node root=tree();if(root==null){finish("請開啟 LINE 聊天室");return;}MessageDetector.Result r=MessageDetector.latest(root,true);
  if(!r.readable()){finish(r.reason);return;}
  MessageDetector.Node target=r.body;while(target.parent!=null&&!target.longClickable&&target!=r.row)target=target.parent;
  Runnable menu=()->handler.postDelayed(()->unsendMenu(op,0,false),240);
  if(target.longClickable&&UiTree.handle(target).performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK))menu.run();else gesture(r.body.box,650,menu,()->finish("無法長按自己的訊息"));
 });}
 void unsendMenu(int op,int attempt,boolean confirmation){if(op!=generation)return;MessageDetector.Node root=tree();MessageDetector.Node action=exact(root,"收回","收回訊息","撤回","撤回消息","Unsend");
  if(action==null){if(attempt<5){handler.postDelayed(()->unsendMenu(op,attempt+1,confirmation),160);return;}finish(confirmation?"已點收回，請確認 LINE 完成狀態":"LINE 未提供收回選項，未點擊刪除");return;}
  if(!UiTree.handle(action).performAction(AccessibilityNodeInfo.ACTION_CLICK)){finish("LINE 收回按鈕無法操作");return;}
  if(confirmation)finish("已操作收回，請確認 LINE 完成狀態");else handler.postDelayed(()->unsendMenu(op,0,true),350);
 }
}
