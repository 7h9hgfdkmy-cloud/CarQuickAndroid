package com.carquick.android;
import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import java.util.*;
import java.util.function.Consumer;
final class ScreenText {
 private static TextRecognizer recognizer;
 static synchronized TextRecognizer recognizer(){if(recognizer==null)recognizer=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());return recognizer;}
 static synchronized void close(){if(recognizer!=null){recognizer.close();recognizer=null;}}
 static void read(Bitmap bitmap,Consumer<String> success,Consumer<Exception> fail){
  TextRecognizer engine=recognizer();
  engine.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener(result->{
   List<Text.TextBlock> blocks=new ArrayList<>(result.getTextBlocks());blocks.removeIf(b->b.getBoundingBox()==null);blocks.sort(Comparator.comparingInt(b->b.getBoundingBox().top));
   List<String> lines=new ArrayList<>();for(Text.TextBlock block:blocks)for(Text.Line line:block.getLines())if(!MessageDetector.metadataText(line.getText()))lines.add(line.getText());success.accept(String.join("\n",lines));
  }).addOnFailureListener(fail::accept).addOnCompleteListener(t->{bitmap.recycle();});
 }
}
