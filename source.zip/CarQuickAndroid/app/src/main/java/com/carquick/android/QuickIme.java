package com.carquick.android;
import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.*;
import android.widget.*;
import android.graphics.Color;
import java.util.*;
public class QuickIme extends InputMethodService {
 static QuickIme visible;String category="跑車";TextView info;
 @Override public void onStartInputView(EditorInfo e,boolean restarting){super.onStartInputView(e,restarting);visible=this;setInputView(keyboard());}
 @Override public void onFinishInputView(boolean finishing){visible=null;super.onFinishInputView(finishing);}
 @Override public void onDestroy(){if(visible==this)visible=null;super.onDestroy();}
 @Override public View onCreateInputView(){return keyboard();}
 static boolean putFromService(String text){QuickIme s=visible;return s!=null&&s.getCurrentInputConnection()!=null&&s.getCurrentInputConnection().commitText(text,1);}
 static boolean sendFromService(){return visible!=null&&visible.send();}
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 View keyboard(){LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(8),dp(6),dp(8),dp(6));root.setBackgroundColor(Color.rgb(248,246,252));
  List<String> categories=Config.categories(this);if(!categories.contains(category)&&!categories.isEmpty())category=categories.get(0);
  LinearLayout tabs=new LinearLayout(this);HorizontalScrollView ts=new HorizontalScrollView(this);ts.addView(tabs);root.addView(ts);
  for(String c:categories)add(tabs,c,()->{category=c;setInputView(keyboard());});
  ScrollView sc=new ScrollView(this);LinearLayout rows=new LinearLayout(this);rows.setOrientation(1);sc.addView(rows);root.addView(sc,new LinearLayout.LayoutParams(-1,dp(160)));
  for(Config.Entry e:Config.entries(this))if(e.category.equals(category))add(rows,e.title+"   "+e.message,()->{Config.active(this,e);InputConnection c=getCurrentInputConnection();if(c!=null)c.commitText(e.message,1);if(info!=null)info.setText("已加入："+e.title);});
  info=new TextView(this);info.setText("點車訊加入文字，再點傳送");info.setTextSize(12);root.addView(info);
  LinearLayout tools=new LinearLayout(this);add(tools,"🌐",()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());add(tools,"⌫",()->{InputConnection c=getCurrentInputConnection();if(c!=null)c.deleteSurroundingText(1,0);});add(tools,"傳送",()->send());root.addView(tools);return root;
 }
 boolean send(){InputConnection c=getCurrentInputConnection();EditorInfo e=getCurrentInputEditorInfo();if(c==null||e==null)return false;int action=e.imeOptions&EditorInfo.IME_MASK_ACTION;if(action==EditorInfo.IME_ACTION_SEND)return c.performEditorAction(action);boolean down=c.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER));c.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER));return down;}
 void add(LinearLayout box,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(14);b.setOnClickListener(v->action.run());box.addView(b);}
}
