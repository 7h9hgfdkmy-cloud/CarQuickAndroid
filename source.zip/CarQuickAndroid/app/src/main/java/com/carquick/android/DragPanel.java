package com.carquick.android;

import android.content.Context;
import android.view.*;
import android.widget.LinearLayout;

/** Intercepts only a drag; ordinary taps remain with the touched child button. */
final class DragPanel extends LinearLayout {
 interface Listener { void moved(float dx,float dy);void ended(); }
 private final int slop;private final Listener listener;
 private float downX,downY;private boolean dragging;
 DragPanel(Context c,Listener listener){super(c);this.listener=listener;slop=ViewConfiguration.get(c).getScaledTouchSlop();setOrientation(VERTICAL);}
 @Override public boolean onInterceptTouchEvent(MotionEvent e){
  if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();dragging=false;return false;}
  if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&FloatingSpec.moved(e.getRawX()-downX,e.getRawY()-downY,slop)){
   dragging=true;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);return true;
  }
  return dragging;
 }
 @Override public boolean onTouchEvent(MotionEvent e){
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();dragging=false;return true;
   case MotionEvent.ACTION_MOVE:if(dragging||FloatingSpec.moved(e.getRawX()-downX,e.getRawY()-downY,slop)){dragging=true;listener.moved(e.getRawX()-downX,e.getRawY()-downY);}return true;
   case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:if(dragging)listener.ended();dragging=false;return true;
   default:return true;
  }
 }
}
