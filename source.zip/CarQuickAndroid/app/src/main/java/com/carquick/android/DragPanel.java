package com.carquick.android;

import android.content.Context;
import android.view.*;
import android.widget.LinearLayout;

/** Immediate drag moves the panel; a button long-press explicitly enters message picking. */
final class DragPanel extends LinearLayout {
 interface Listener { void moved(float dx,float dy);void ended(); }
 interface Picker { void moved(float x,float y);void ended(float x,float y,boolean cancelled); }
 private final int slop;private final Listener listener;
 private float downX,downY,lastX,lastY,selectionX,selectionY;private boolean dragging,selectionMoved;private Picker picker;
 DragPanel(Context c,Listener listener){super(c);this.listener=listener;slop=ViewConfiguration.get(c).getScaledTouchSlop();setOrientation(VERTICAL);}
 void beginSelection(Picker p){dragging=false;selectionMoved=false;selectionX=lastX;selectionY=lastY;picker=p;p.moved(lastX,lastY);}
 void cancelSelection(){picker=null;dragging=false;}
 @Override public boolean onInterceptTouchEvent(MotionEvent e){
  lastX=e.getRawX();lastY=e.getRawY();
  if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=lastX;downY=lastY;dragging=false;return false;}
  if(picker!=null)return true;
  if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&FloatingSpec.moved(lastX-downX,lastY-downY,slop)){
   dragging=true;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);return true;
  }
  return dragging;
 }
 @Override public boolean onTouchEvent(MotionEvent e){
  lastX=e.getRawX();lastY=e.getRawY();
  if(picker!=null){
   if(e.getActionMasked()==MotionEvent.ACTION_MOVE){selectionMoved|=FloatingSpec.moved(lastX-selectionX,lastY-selectionY,slop);picker.moved(lastX,lastY);}
   else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL||e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN){Picker p=picker;picker=null;p.ended(lastX,lastY,e.getActionMasked()!=MotionEvent.ACTION_UP||!selectionMoved);}
   return true;
  }
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:downX=lastX;downY=lastY;dragging=false;return true;
   case MotionEvent.ACTION_MOVE:if(dragging||FloatingSpec.moved(lastX-downX,lastY-downY,slop)){dragging=true;listener.moved(lastX-downX,lastY-downY);}return true;
   case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:if(dragging)listener.ended();dragging=false;return true;
   default:return true;
  }
 }
}
