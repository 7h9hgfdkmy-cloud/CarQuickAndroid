package com.carquick.android;
import android.content.Context;
import android.os.*;
import android.provider.Settings;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.concurrent.*;
import java.util.function.Consumer;

final class Membership {
 private static Membership instance;
 static synchronized Membership get(Context context){if(instance==null)instance=new Membership(context.getApplicationContext());return instance;}
 static boolean allowed(){if(BuildMode.TEST_VERSION)return true;Membership m=instance;return m!=null&&m.lease.valid(SystemClock.elapsedRealtime());}
 private final Context context;private final LeaseClock lease=new LeaseClock();
 private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();private final Handler main=new Handler(Looper.getMainLooper());
 private volatile String api="",publicKey="",device="",session="",message="請登入會員帳號";
 private volatile String username="";private volatile long memberExpiry=0;private volatile int revision=0,authGeneration=0;
 private Membership(Context context){this.context=context;if(BuildMode.TEST_VERSION){message="測試版：免登入，無使用期限";return;}
  try(InputStream in=context.getAssets().open("member-config.json")){JSONObject c=new JSONObject(new String(read(in),StandardCharsets.UTF_8));api=c.optString("api_url","").replaceAll("/+$","");publicKey=c.optString("public_key","");URI u=new URI(api);if(!"https".equals(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null)api="";}catch(Exception e){api="";}
  try{String id=Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ANDROID_ID);if(id==null||id.isEmpty())throw new Exception();byte[] hash=MessageDigest.getInstance("SHA-256").digest((context.getPackageName()+":"+id).getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:hash)out.append(String.format("%02x",b&255));device=out.toString();}catch(Exception e){message="無法識別此裝置";}
  session=MemberVault.read(context);username=Config.prefs(context).getString("memberUsername","");
  if(!configured())message="會員服務尚未設定，請先部署後台並設定連線資料";
  worker.scheduleWithFixedDelay(()->{if(!session.isEmpty()&&configured()&&lease.remaining(SystemClock.elapsedRealtime())<90000)refreshInternal();},0,30,TimeUnit.SECONDS);
 }
 boolean configured(){if(BuildMode.TEST_VERSION)return false;return !api.isEmpty()&&!publicKey.isEmpty()&&!device.isEmpty();}
 String status(){if(BuildMode.TEST_VERSION)return "測試版：免登入，無使用期限";if(allowed())return "會員有效";if(!configured())return "會員服務尚未設定";if(message.equals("會員有效")||message.equals("連線暫時中斷，保留短期驗證"))return "需要連線重新驗證會員資格";return message;}
 String username(){return username;}
 long expires(){return memberExpiry;}
 long remaining(){return lease.remaining(SystemClock.elapsedRealtime());}
 void login(String name,String password,Consumer<String> callback){
  if(!configured()){callback.accept("需要先設定會員服務，才能登入。");return;}
  int operation=++authGeneration;worker.execute(()->{try{JSONObject body=new JSONObject();body.put("username",name.trim());body.put("password",password);body.put("device",device);JSONObject result=request("/v1/login",body,"");
   synchronized(this){if(operation!=authGeneration)return;String token=result.getString("session");MemberVault.write(context,token);accept(result.getString("license"));session=token;Config.prefs(context).edit().putString("memberUsername",username).apply();}notifyChange();main.post(()->callback.accept(allowed()?"登入成功":"登入成功，但會員尚未開通或已到期"));
  }catch(Exception e){synchronized(this){if(operation!=authGeneration)return;lease.clear();session="";MemberVault.clear(context);}notifyChange();main.post(()->callback.accept(e.getMessage()==null?"登入失敗":e.getMessage()));}});
 }
 void refresh(Consumer<String> callback){worker.execute(()->{refreshInternal();main.post(()->callback.accept(status()));});}
 private void refreshInternal(){if(session.isEmpty()||!configured())return;String token=session;int operation=authGeneration;try{JSONObject body=new JSONObject();body.put("device",device);JSONObject result=request("/v1/check",body,token);synchronized(this){if(operation!=authGeneration||!token.equals(session))return;accept(result.getString("license"));}}
  catch(HttpFailure e){synchronized(this){if(operation!=authGeneration||!token.equals(session))return;if(e.status==401||e.status==403){lease.clear();session="";MemberVault.clear(context);}message=e.getMessage();}}
  catch(Exception e){if(operation!=authGeneration||!token.equals(session))return;message=allowed()?"連線暫時中斷，保留短期驗證":"無法連線驗證會員，請檢查網路";}
  notifyChange();
 }
 void logout(){String token;synchronized(this){++authGeneration;token=session;session="";lease.clear();memberExpiry=0;username="";message="已登出，請登入會員帳號";MemberVault.clear(context);Config.prefs(context).edit().remove("memberUsername").apply();}notifyChange();
  worker.execute(()->{try{JSONObject body=new JSONObject();body.put("device",device);if(!token.isEmpty())request("/v1/logout",body,token);}catch(Exception ignored){}});
 }
 private void accept(String jwt)throws Exception{
  String[] parts=jwt.split("\\.");if(parts.length!=3)throw new Exception("會員憑證格式錯誤");JSONObject head=new JSONObject(new String(Base64.getUrlDecoder().decode(parts[0]),StandardCharsets.UTF_8));if(!"RS256".equals(head.optString("alg")))throw new Exception("會員憑證格式錯誤");
  JSONObject claims=new JSONObject(LicenseSignature.payload(jwt,publicKey));if(!device.equals(claims.getString("device")))throw new Exception("會員憑證與手機不符");
  boolean granted=lease.grant(SystemClock.elapsedRealtime(),claims.getLong("iat"),claims.getLong("exp"),claims.getBoolean("active"));username=claims.getString("sub");memberExpiry=claims.getLong("member_exp");message=granted?"會員有效":"會員尚未開通或已到期，請聯絡管理員續費";
 }
 private void notifyChange(){main.post(()->Config.prefs(context).edit().putInt("memberRevision",++revision).apply());}
 private JSONObject request(String path,JSONObject body,String token)throws Exception{
  HttpURLConnection connection=(HttpURLConnection)new URL(api+path).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(6000);connection.setReadTimeout(6000);connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Accept","application/json");if(!token.isEmpty())connection.setRequestProperty("Authorization","Bearer "+token);
  try{byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=connection.getOutputStream()){out.write(bytes);}int code=connection.getResponseCode();InputStream stream=code>=200&&code<300?connection.getInputStream():connection.getErrorStream();if(stream==null)throw new HttpFailure(code,"會員服務暫時無法使用");JSONObject response;try(InputStream in=stream){response=new JSONObject(new String(read(in),StandardCharsets.UTF_8));}if(code<200||code>=300)throw new HttpFailure(code,response.optString("error","會員服務暫時無法使用"));return response;}finally{connection.disconnect();}
 }
 static byte[] read(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=in.read(buffer))!=-1){if(out.size()+count>65536)throw new IOException("回應過大");out.write(buffer,0,count);}return out.toByteArray();}
 static final class HttpFailure extends Exception{final int status;HttpFailure(int status,String message){super(message);this.status=status;}}
}
