package com.carquick.android;

import java.util.*;

/** Platform-independent selection rules; no stored LINE resource IDs. */
final class MessageDetector {
 static final class Box {
  int left,top,right,bottom;
  Box(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;}
  int width(){return right-left;}int height(){return bottom-top;}
  int cx(){return (left+right)/2;}int cy(){return (top+bottom)/2;}
  boolean intersects(Box b){return left<b.right&&right>b.left&&top<b.bottom&&bottom>b.top;}
 }
 static final class Node {
  String id="",text="",description="",kind="";Box box=new Box(0,0,0,0);
  boolean visible=true,editable,hint,clickable,longClickable,scrollable;
  Object handle;Node parent;List<Node> children=new ArrayList<>();
  Node add(Node n){n.parent=this;children.add(n);return this;}
 }
 static final class Result {
  Node row,body;String text="",reason="";boolean media;
  Result(Node row){this.row=row;}
  boolean readable(){return !text.isEmpty()&&!media;}
 }
 static List<Node> flatten(Node n){List<Node> out=new ArrayList<>();walk(n,out);return out;}
 static void walk(Node n,List<Node> out){if(n==null)return;out.add(n);for(Node c:n.children)walk(c,out);}
 static boolean metadataText(String raw){String s=raw.trim();return s.isEmpty()||s.matches("(?i)(已讀|已读|read)(\\s*\\d+)?")||s.matches("(?i)(上午|下午|AM|PM)?\\s*\\d{1,2}[:：]\\d{2}(\\s*(AM|PM))?")||s.matches("(今天|昨天|今日|昨日|Today|Yesterday|未讀訊息|未读消息|Unread messages)")||s.matches("\\d{1,4}[/-]\\d{1,2}([/-]\\d{1,2})?");}
 static boolean metadataId(String id){String s=id.toLowerCase(Locale.ROOT);return s.matches(".*(timestamp|sender_name|sendername|display_name|read_count|readcount|date_separator|profile_name).*" )||s.endsWith("/name")||s.endsWith("/time")||s.endsWith("/date")||s.endsWith("/status");}
 static boolean bodyId(String id){String s=id.toLowerCase(Locale.ROOT);return !metadataId(s)&&(s.contains("message_text")||s.contains("messagetext")||s.contains("chat_message")||s.contains("message_body")||s.contains("message_content")||s.contains("content_text")||s.contains("chat_content"));}
 static Node editor(Node root){Node best=null;for(Node n:flatten(root))if(n.visible&&n.editable&&n.box.height()>0&&(best==null||n.box.bottom>best.box.bottom))best=n;return best;}
 static Node list(Node root){Node edit=editor(root);int floor=edit==null?root.box.bottom:edit.box.top;Node best=null;int max=-1;
  for(Node n:flatten(root)){String kind=n.kind.toLowerCase(Locale.ROOT);if(!n.visible||!(kind.contains("recyclerview")||kind.contains("listview")||n.scrollable))continue;boolean containsEditor=false;for(Node c:flatten(n))if(c.editable)containsEditor=true;if(containsEditor)continue;
   if(n.box.width()<root.box.width()/2||n.box.height()<root.box.height()/8||n.box.top>=floor)continue;
   int score=0;for(Node c:n.children)if(c.visible&&c.box.top<floor){score+=2;for(Node x:flatten(c))if(!x.editable&&!metadataText(x.text))score+=bodyId(x.id)?8:1;}
   if(score>max){max=score;best=n;}
  }return best;
 }
 static List<Node> rows(Node root){Node list=list(root);List<Node> rows=new ArrayList<>();Node e=editor(root);int top=root.box.top+root.box.height()/12;int bottom=e==null?root.box.bottom-root.box.height()/10:e.box.top;
  if(list!=null){for(Node n:list.children)if(n.visible&&n.box.height()>0&&n.box.bottom>top&&n.box.top<bottom)rows.add(n);}
  else{
   // Fallback only for nodes whose IDs describe a message body, never all screen text.
   for(Node n:flatten(root))if(n.visible&&!n.editable&&bodyId(n.id)&&n.box.top>top&&n.box.bottom<=bottom){Node row=n;for(int i=0;i<3&&row.parent!=null&&!row.clickable&&!row.longClickable;i++)row=row.parent;if(!rows.contains(row))rows.add(row);}
  }
  rows.sort(Comparator.comparingInt(n->n.box.bottom));return rows;
 }
 static boolean onlySeparator(Node row){boolean any=false;for(Node n:flatten(row)){if(n.text.trim().isEmpty())continue;any=true;if(bodyId(n.id)||!metadataText(n.text)||n.clickable||n.longClickable)return false;}return any;}
 static Result parse(Node row){Result r=new Result(row);List<Node> text=new ArrayList<>();
  for(Node n:flatten(row)){
   String id=n.id.toLowerCase(Locale.ROOT),desc=n.description.toLowerCase(Locale.ROOT);
   if(n.visible&&(id.contains("sticker")||id.contains("voice_message")||id.contains("message_photo")||id.contains("message_image")||desc.equals("貼圖")||desc.equals("照片")||desc.equals("sticker")||desc.equals("photo")))r.media=true;
   if(!n.visible||n.editable||n.hint||n.text.trim().isEmpty()||(metadataText(n.text)&&!bodyId(n.id))||metadataId(n.id))continue;
   boolean duplicate=false;for(Node c:n.children)if(c.visible&&n.text.equals(c.text)){duplicate=true;break;}if(!duplicate)text.add(n);
  }
  if(r.media){r.reason="最新一則是圖片、貼圖或語音";return r;}
  if(text.isEmpty()){r.reason="訊息文字未提供給無障礙服務";return r;}
  Node best=null;long max=Long.MIN_VALUE;
  for(Node n:text){long area=(long)Math.max(1,n.box.width())*Math.max(1,n.box.height());long score=area+(bodyId(n.id)?100000000L:0)+(n.longClickable?10000000L:0);if(score>max){max=score;best=n;}}
  r.body=best;List<Node> pieces=new ArrayList<>();
  for(Node n:text)if(n==best||(!best.id.isEmpty()&&best.id.equals(n.id)&&Math.abs(n.box.left-best.box.left)<Math.max(16,row.box.width()/12)))pieces.add(n);
  pieces.sort(Comparator.comparingInt((Node n)->n.box.top).thenComparingInt(n->n.box.left));
  LinkedHashSet<String> strings=new LinkedHashSet<>();for(Node n:pieces)strings.add(n.text.trim());r.text=String.join("\n",strings);return r;
 }
 static Result latest(Node root,boolean own){List<Node> all=rows(root);for(int i=all.size()-1;i>=0;i--){Node row=all.get(i);if(onlySeparator(row))continue;Result r=parse(row);
   if(!own)return r;
   if(r.body==null){r.reason="無法確認自己最新的訊息";return r;}
   // Supported LINE layout: incoming body starts near left, outgoing ends near right.
   boolean right=r.body.box.right>root.box.right-root.box.width()/8&&r.body.box.left>root.box.left+root.box.width()/8;
   if(right)return r;
   if(r.body.box.right>root.box.right-root.box.width()/8){r.text="";r.reason="訊息太寬，無法確認是自己發出，停止收回";return r;}
  }Result r=new Result(null);r.reason=own?"畫面內沒有可辨識的自己訊息":"沒有找到聊天室訊息";return r;}
}
