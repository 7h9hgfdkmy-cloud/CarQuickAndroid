package com.carquick.android;
/** Test distribution explicitly runs without the monthly membership service. */
final class BuildMode {
 static final boolean TEST_VERSION=true;
}
