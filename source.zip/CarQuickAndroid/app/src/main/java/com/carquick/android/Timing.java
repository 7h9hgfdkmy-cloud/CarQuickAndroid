package com.carquick.android;
final class Timing {
 static final long TAP_GUARD_MS=250;
 static int retryDelay(int attempt){return attempt<4?40:80;}
 static boolean endIndex(int total,int row,int span){return total>0&&row>=0&&span>0&&row+span>=total;}
}
