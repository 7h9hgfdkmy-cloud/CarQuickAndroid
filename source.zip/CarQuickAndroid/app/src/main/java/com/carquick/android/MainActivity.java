package com.carquick.android;

import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 final int RED=Color.rgb(228,83,83), BG=Color.rgb(247,246,252);
 String selected="跑車";LinearLayout body;int page=0;
 @Override public void onCreate(Bundle b){super.onCreate(b);Membership.get(this);if(!Membership.allowed())page=3;render();}
 @Override protected void onResume(){super.onResume();render();}
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 void render(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(20),dp(18),dp(12));setContentView(root);
  if(android.os.Build.VERSION.SDK_INT>=35)root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());root.setPadding(dp(18)+bars.left,dp(12)+bars.top,dp(18)+bars.right,dp(12)+bars.bottom);return insets;});
  TextView header=text(page==0?"懸浮按鈕":(page==1?"快捷鍵盤":(page==3?(BuildMode.TEST_VERSION?"測試版資訊":"會員登入"):"設定")),28,Color.BLACK);header.setTypeface(null,Typeface.BOLD);root.addView(header);
  TextView subtitle=text("車訊快捷助手 · 0.7.2 測試版",13,Color.GRAY);subtitle.setPadding(0,dp(5),0,dp(14));root.addView(subtitle);
  ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(page==0)showFloating();else if(page==1)showEntries();else if(page==3)showMember();else showSettings();
  LinearLayout nav=new LinearLayout(this);nav.setPadding(0,dp(10),0,0);
  Button floating=button("懸浮按鈕",()->{page=0;render();});Button my=button("快捷鍵盤",()->{page=1;render();});Button settings=button("設定",()->{page=2;render();});nav.addView(floating,new LinearLayout.LayoutParams(0,-2,1));nav.addView(my,new LinearLayout.LayoutParams(0,-2,1));nav.addView(settings,new LinearLayout.LayoutParams(0,-2,1));Button member=button(BuildMode.TEST_VERSION?"版本":"會員",()->{page=3;render();});nav.addView(member,new LinearLayout.LayoutParams(0,-2,1));root.addView(nav);
 }
 Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(RED);b.setOnClickListener(v->action.run());return b;}
 void showEntries(){

  HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);LinearLayout tabs=new LinearLayout(this);sc.addView(tabs);body.addView(sc);
  List<String> cats=Config.categories(this);if(!cats.contains(selected))selected=cats.isEmpty()?"跑車":cats.get(0);
  for(String name:cats){Button b=button(name,()->{selected=name;render();});b.setTextColor(name.equals(selected)?Color.WHITE:Color.DKGRAY);b.setBackground(bg(name.equals(selected)?categoryColor(name):Color.WHITE,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(44));p.setMargins(0,0,dp(8),0);tabs.addView(b,p);b.setOnLongClickListener(v->{categoryMenu(name);return true;});}
  body.addView(button("＋ 新增分類",()->editCategory(null)));
  TextView instruction=text("點選車訊可編輯按鈕內容；長按分類可改名。",13,Color.GRAY);instruction.setPadding(0,dp(8),0,dp(12));body.addView(instruction);
  for(Config.Entry e:Config.entries(this))if(e.category.equals(selected)){
   LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(bg(Color.WHITE,18));
   TextView title=text(e.title+"  ›",21,Color.BLACK);title.setTypeface(null,Typeface.BOLD);card.addView(title);
   TextView content=text(e.message,16,Color.DKGRAY);content.setPadding(0,dp(6),0,dp(8));card.addView(content);

   card.setOnClickListener(v->editEntry(e));title.setOnClickListener(v->editEntry(e));content.setOnClickListener(v->editEntry(e));
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));body.addView(card,p);
  }
  body.addView(button("＋ 新增車訊按鈕",()->editEntry(null)));
 }
 int categoryColor(String s){if(s.equals("跑車"))return Color.rgb(194,143,195);if(s.equals("長單"))return Color.rgb(221,128,67);if(s.equals("未見"))return Color.rgb(155,118,140);return RED;}
 EditText field(LinearLayout box,String hint,String initial){EditText e=new EditText(this);e.setHint(hint);e.setText(initial);e.setTextSize(17);box.addView(e);return e;}
 void editEntry(Config.Entry old){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(10),dp(22),0);
  TextView info=text("每個按鈕可分別設定名稱與真正發出的車訊。",14,Color.GRAY);form.addView(info);
  EditText title=field(form,"按鈕名稱，例如 5分",old==null?"":old.title);
  EditText message=field(form,"發送內容，例如 0000/黑",old==null?"0000/黑":old.message);message.setMinLines(3);message.setGravity(Gravity.TOP);
  List<String> cats=Config.categories(this);if(cats.isEmpty()){cats.add("跑車");Config.saveCategories(this,cats);}Spinner category=new Spinner(this);category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));category.setSelection(Math.max(0,cats.indexOf(old==null?selected:old.category)));form.addView(category);
  AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"新增車訊按鈕":"編輯車訊按鈕").setView(form).setPositiveButton("儲存",null).setNegativeButton("取消",null).setNeutralButton(old==null?"":"刪除",null).create();d.setOnShowListener(v->{
   d.getButton(-1).setOnClickListener(w->{String a=title.getText().toString().trim(),m=message.getText().toString().trim();if(a.isEmpty()||m.isEmpty()){message.setError("請輸入按鈕名稱及車訊");return;}String cat=String.valueOf(category.getSelectedItem());List<Config.Entry> all=Config.entries(this);if(old==null)all.add(new Config.Entry(cat,a,m));else for(Config.Entry e:all)if(e.id.equals(old.id)){e.title=a;e.message=m;e.category=cat;}Config.save(this,all);selected=cat;d.dismiss();render();});
   if(old==null)d.getButton(-3).setVisibility(View.GONE);else d.getButton(-3).setOnClickListener(w->{new AlertDialog.Builder(this).setTitle("刪除這個車訊按鈕？").setPositiveButton("刪除",(x,y)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.id.equals(old.id));Config.save(this,all);d.dismiss();render();}).setNegativeButton("取消",null).show();});
  });d.show();
 }
 void editCategory(String old){EditText input=new EditText(this);input.setHint("分類名稱");input.setText(old==null?"":old);new AlertDialog.Builder(this).setTitle(old==null?"新增分類":"修改分類名稱").setView(input).setPositiveButton("儲存",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;List<String> cats=Config.categories(this);if(cats.contains(name)&&!name.equals(old)){toast("此分類已存在");return;}if(old!=null){int i=cats.indexOf(old);if(i>=0)cats.set(i,name);List<Config.Entry> all=Config.entries(this);for(Config.Entry e:all)if(e.category.equals(old))e.category=name;Config.save(this,all);}else cats.add(name);Config.saveCategories(this,cats);selected=name;render();}).setNegativeButton("取消",null).show();}
 void categoryMenu(String name){new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"修改名稱","刪除分類"},(d,w)->{if(w==0)editCategory(name);else new AlertDialog.Builder(this).setTitle("刪除分類及其中的車訊？").setPositiveButton("刪除",(a,b)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.category.equals(name));Config.save(this,all);List<String> cats=Config.categories(this);cats.remove(name);Config.saveCategories(this,cats);render();}).setNegativeButton("取消",null).show();}).show();}
 void showSettings(){
  permissionControls();
  body.addView(button(BuildMode.TEST_VERSION?"測試版資訊":"會員登入與使用期限",()->{page=3;render();}));
  body.addView(button("全部車訊套用 0000/黑",()->new AlertDialog.Builder(this).setTitle("將全部車訊改為 0000/黑？").setMessage("會修改所有懸浮按鈕及快捷鍵盤的車訊，保留按鈕名稱。此操作會覆蓋自訂車訊。").setPositiveButton("全部套用",(d,w)->{Config.resetAllMessages(this);render();toast("已全部套用 0000/黑");}).setNegativeButton("取消",null).show()));
  body.addView(button("啟用 LINE 懸浮助手",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
  body.addView(button("啟用車訊快捷鍵盤",()->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
  body.addView(button("切換鍵盤",()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));
  TextView help=text("使用方式\n\n① 在『懸浮按鈕』設定需要的按鈕數量。\n② 分別設定每個按鈕的文字及車訊。\n③ 開啟 LINE，點對應按鈕就發送該按鈕的車訊。\n\n每個按鈕可選『最新訊息＋車訊』或『只發車訊』。\n\n按住任一按鈕或面板空白處滑動，即可移動整個面板；放開後位置會儲存。短按才會發送，拖曳不會發送。\n\n可以調整按鈕大小、透明度和每列數量。收回按鈕可另外開關。",16,Color.DKGRAY);help.setPadding(dp(10),dp(18),dp(10),dp(20));body.addView(help);
  body.addView(text("最新訊息辨識及 LINE 傳送仍需你的手機實測；新版只改變懸浮按鈕設定與操作方式。",14,Color.GRAY));
 }
 void showFloating(){
  permissionControls();
  Switch enabled=new Switch(this);enabled.setText("開啟懸浮按鈕");enabled.setChecked(Config.floatingEnabled(this));enabled.setTextSize(18);body.addView(enabled);
  TextView enabledHint=text(Config.floatingEnabled(this)?"已開啟，回到 LINE 就會顯示。":"已關閉，懸浮面板不會顯示。",14,Color.GRAY);enabledHint.setPadding(0,0,0,dp(14));body.addView(enabledHint);
  enabled.setOnCheckedChangeListener((view,checked)->{Config.prefs(this).edit().putBoolean("floatingEnabled",checked).apply();enabledHint.setText(checked?"已開啟，回到 LINE 就會顯示。":"已關閉，懸浮面板不會顯示。");});
  TextView help=text("每個懸浮按鈕直接發送自己的車訊，不必切換。",15,Color.DKGRAY);help.setPadding(0,0,0,dp(8));body.addView(help);
  body.addView(button("車訊按鈕數量："+Config.floatingCount(this)+" 個  ›",()->pickNumber("車訊按鈕數量（不含收回）",1,FloatingSpec.MAX_COUNT,Config.floatingCount(this),v->{Config.floatingCount(this,v);render();})));
  body.addView(button("每列："+Config.floatingColumns(this)+" 個  ›",()->pickNumber("每列按鈕數量",1,4,Config.floatingColumns(this),v->{Config.prefs(this).edit().putInt("floatingColumns",v).apply();render();})));
  LinearLayout preview=new LinearLayout(this);preview.setOrientation(1);preview.setPadding(dp(4),dp(4),dp(4),dp(4));preview.setBackground(bg(Color.argb(70,205,184,213),10));
  TextView previewTitle=text("外觀預覽",13,Color.GRAY);previewTitle.setPadding(0,dp(8),0,dp(6));body.addView(previewTitle);body.addView(preview);
  updatePreview(preview);
  slider("floatingSize","按鈕高度",28,60,Config.floatingSize(this),"dp",preview);
  slider("floatingOpacity","不透明度",20,100,Config.floatingOpacity(this),"%（越低越透明）",preview);
  Switch undo=new Switch(this);undo.setText("顯示收回按鈕");undo.setChecked(Config.floatingUndo(this));undo.setOnCheckedChangeListener((v,checked)->{Config.prefs(this).edit().putBoolean("floatingUndo",checked).apply();updatePreview(preview);});body.addView(undo);
  TextView hint=text("點下方卡片，分別設定每個按鈕的文字及發送內容。",14,Color.GRAY);hint.setPadding(0,dp(16),0,dp(10));body.addView(hint);
  int index=0;for(Config.FloatingButton spec:Config.floating(this)){
   final int number=++index;LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(bg(Color.WHITE,14));
   TextView title=text(number+".  "+spec.title+"  ✎",20,Color.BLACK);title.setTypeface(null,Typeface.BOLD);card.addView(title);
   TextView content=text(spec.message.isEmpty()?"尚未設定車訊，點此輸入":spec.message,15,Color.DKGRAY);content.setPadding(0,dp(7),0,dp(5));card.addView(content);
   TextView mode=text(spec.append?"最新訊息 ＋ 此按鈕車訊":"只發送此按鈕車訊",12,RED);card.addView(mode);
   card.setOnClickListener(v->editFloating(spec,number));title.setOnClickListener(v->editFloating(spec,number));content.setOnClickListener(v->editFloating(spec,number));mode.setOnClickListener(v->editFloating(spec,number));
   LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.setMargins(0,0,0,dp(10));body.addView(card,params);
  }
 }
 interface NumberChoice { void select(int value); }
 void pickNumber(String title,int min,int max,int value,NumberChoice choice){NumberPicker picker=new NumberPicker(this);picker.setMinValue(min);picker.setMaxValue(max);picker.setValue(value);picker.setWrapSelectorWheel(false);new AlertDialog.Builder(this).setTitle(title).setView(picker).setPositiveButton("儲存",(d,w)->choice.select(picker.getValue())).setNegativeButton("取消",null).show();}
 void slider(String key,String title,int min,int max,int value,String unit,LinearLayout preview){
  TextView label=text(title+"："+value+unit,14,Color.DKGRAY);label.setPadding(0,dp(10),0,0);body.addView(label);SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(value-min);body.addView(bar);
  bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int progress,boolean fromUser){int v=min+progress;label.setText(title+"："+v+unit);if(fromUser){Config.prefs(MainActivity.this).edit().putInt(key,v).apply();updatePreview(preview);}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
 }
 void updatePreview(LinearLayout grid){
  grid.removeAllViews();grid.setAlpha(Config.floatingOpacity(this)/100f);int size=Config.floatingSize(this),width=FloatingSpec.width(size),columns=Config.floatingColumns(this);int available=getResources().getDisplayMetrics().widthPixels-dp(50);columns=Math.min(columns,Math.max(1,available/dp(width+4)));
  LinearLayout row=null;int index=0;List<String> labels=new ArrayList<>();for(Config.FloatingButton b:Config.floating(this))labels.add(b.title);if(Config.floatingUndo(this))labels.add("收回");
  for(String label:labels){if(index++%columns==0){row=new LinearLayout(this);grid.addView(row);}TextView t=text(label,size<36?11:12,Color.rgb(50,42,57));t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setEllipsize(android.text.TextUtils.TruncateAt.END);t.setBackground(bg(Color.rgb(243,228,244),8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(width),dp(size));p.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(t,p);}
 }
 void editFloating(Config.FloatingButton old,int number){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(8),dp(22),0);
  form.addView(text("這個按鈕會直接使用以下車訊發送。",14,Color.GRAY));
  EditText title=field(form,"按鈕上的文字",old.title);EditText message=field(form,"此按鈕要發送的車訊",old.message);message.setMinLines(3);message.setGravity(Gravity.TOP);
  Switch append=new Switch(this);append.setText("加上 LINE 最新訊息");append.setChecked(old.append);form.addView(append);form.addView(text("開啟：最新訊息＋車訊；關閉：只發車訊。",13,Color.GRAY));
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("設定按鈕 "+number).setView(form).setPositiveButton("儲存",null).setNegativeButton("取消",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String label=title.getText().toString().trim(),content=message.getText().toString().trim();if(label.isEmpty()){title.setError("請輸入按鈕文字");return;}if(content.isEmpty()){message.setError("請輸入車訊");return;}List<Config.FloatingButton> all=Config.allFloating(this);for(Config.FloatingButton b:all)if(b.id.equals(old.id)){b.title=label;b.message=content;b.append=append.isChecked();}Config.saveFloating(this,all);dialog.dismiss();render();}));dialog.show();
 }
 void permissionControls(){
  boolean enabled=false;
  android.view.accessibility.AccessibilityManager manager=(android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
  if(manager!=null)for(android.accessibilityservice.AccessibilityServiceInfo service:manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){
   android.content.pm.ServiceInfo info=service.getResolveInfo().serviceInfo;
   if(getPackageName().equals(info.packageName)&&(getPackageName()+".LineService").equals(info.name))enabled=true;
  }
  TextView status=text(enabled?"無障礙助手：已啟用":"無障礙助手：尚未啟用",14,enabled?Color.rgb(48,131,83):RED);status.setPadding(0,dp(6),0,dp(6));body.addView(status);
  if(!enabled){
   body.addView(button("受限制的設定／App 資訊",()->new AlertDialog.Builder(this).setTitle("允許受限制的設定").setMessage("下一步會開啟本 App 的系統資訊頁。\n\n請點右上角 ⋮ → 允許受限制的設定，依系統提示完成驗證。\n\n完成後回到 App，再開啟無障礙服務。不同手機的選項位置可能不同；這個按鈕不會自動授權。").setPositiveButton("前往 App 資訊",(d,w)->openAppInfo()).setNegativeButton("取消",null).show()));
   body.addView(button("開啟無障礙服務設定",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
  }
 }
 void openAppInfo(){
  try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName())));}
  catch(android.content.ActivityNotFoundException e){toast("請到手機設定 → 應用程式 → 車訊快捷助手 → App 資訊");}
 }
 void showMember(){
  if(BuildMode.TEST_VERSION){
   body.addView(text("目前為免登入測試版",22,Color.rgb(48,131,83)));
   body.addView(text("可直接測試懸浮按鈕、車訊傳送、收回及快捷鍵盤。無需會員帳號或後台連線，也沒有月租到期限制。",16,Color.DKGRAY));
   body.addView(text("預設車訊：0000/黑。請到懸浮按鈕分頁設定各個按鈕的文字及發送內容。",16,Color.GRAY));return;
  }
  Membership m=Membership.get(this);TextView status=text(m.status(),20,Membership.allowed()?Color.rgb(48,131,83):RED);status.setTypeface(null,Typeface.BOLD);status.setPadding(0,dp(10),0,dp(12));body.addView(status);
  if(!m.username().isEmpty())body.addView(text("會員帳號："+m.username(),16,Color.DKGRAY));
  if(m.expires()>0){java.text.SimpleDateFormat date=new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm",java.util.Locale.TAIWAN);date.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Taipei"));body.addView(text("使用期限："+date.format(new java.util.Date(m.expires()*1000)),16,Color.DKGRAY));}
  if(!m.configured()){body.addView(text("會員服務尚未啟用，請聯絡管理員完成啟用後再登入。此版本需有效會員資格才能發送車訊或收回訊息；按鈕設定仍可編輯。",16,Color.DKGRAY));return;}
  body.addView(text("使用管理員提供的帳號登入。一個帳號限綁定一支手機；續費或更換手機請聯絡管理員。",15,Color.GRAY));
  EditText name=field(body,"會員帳號",m.username());name.setSingleLine(true);name.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
  EditText password=field(body,"密碼","");password.setSingleLine(true);password.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  TextView result=text("",14,RED);body.addView(result);
  Button login=button("登入",()->{});login.setOnClickListener(v->{String account=name.getText().toString().trim(),secret=password.getText().toString();if(account.isEmpty()||secret.isEmpty()){result.setText("請輸入帳號與密碼");return;}login.setEnabled(false);result.setText("正在登入…");m.login(account,secret,message->{if(isFinishing())return;password.setText("");login.setEnabled(true);result.setText(message);if(!m.username().isEmpty()){render();toast(message);}});});body.addView(login);
  body.addView(button("重新驗證／更新期限",()->{result.setText("正在驗證…");m.refresh(message->{if(!isFinishing()){render();toast(message);}});}));
  if(!m.username().isEmpty())body.addView(button("登出",()->{m.logout();render();}));
  TextView note=text("會員資格在背景定期驗證，操作車訊時不會逐次連網。請保持網路可用；到期或長時間無法驗證時會停用發送與收回。",14,Color.GRAY);note.setPadding(0,dp(16),0,0);body.addView(note);
 }
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
