package com.carquick.android;

import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 final int RED=Color.rgb(228,83,83), BG=Color.rgb(247,246,252);
 String selected="跑車";LinearLayout body;int page=0;
 @Override public void onCreate(Bundle b){super.onCreate(b);render();}
 @Override protected void onResume(){super.onResume();render();}
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 void render(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(20),dp(18),dp(12));setContentView(root);
  TextView header=text(page==0?"我的快捷鍵盤":"設定",28,Color.BLACK);header.setTypeface(null,Typeface.BOLD);root.addView(header);
  TextView subtitle=text("車訊快捷助手 · 0.2",13,Color.GRAY);subtitle.setPadding(0,dp(5),0,dp(14));root.addView(subtitle);
  ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(page==0)showEntries();else showSettings();
  LinearLayout nav=new LinearLayout(this);nav.setPadding(0,dp(10),0,0);
  Button my=button("▦  我的鍵盤",()->{page=0;render();});Button settings=button("⚙  設定",()->{page=1;render();});nav.addView(my,new LinearLayout.LayoutParams(0,-2,1));nav.addView(settings,new LinearLayout.LayoutParams(0,-2,1));root.addView(nav);
 }
 Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(RED);b.setOnClickListener(v->action.run());return b;}
 void showEntries(){
  Config.Entry active=Config.active(this);TextView current=text(active==null?"尚未新增車訊":"懸浮車訊按鈕目前使用："+active.title,14,RED);current.setPadding(0,0,0,dp(10));body.addView(current);
  HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);LinearLayout tabs=new LinearLayout(this);sc.addView(tabs);body.addView(sc);
  List<String> cats=Config.categories(this);if(!cats.contains(selected))selected=cats.isEmpty()?"跑車":cats.get(0);
  for(String name:cats){Button b=button(name,()->{selected=name;render();});b.setTextColor(name.equals(selected)?Color.WHITE:Color.DKGRAY);b.setBackground(bg(name.equals(selected)?categoryColor(name):Color.WHITE,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(44));p.setMargins(0,0,dp(8),0);tabs.addView(b,p);b.setOnLongClickListener(v->{categoryMenu(name);return true;});}
  body.addView(button("＋ 新增分類",()->editCategory(null)));
  TextView instruction=text("點選車訊可編輯按鈕內容；長按分類可改名。",13,Color.GRAY);instruction.setPadding(0,dp(8),0,dp(12));body.addView(instruction);
  for(Config.Entry e:Config.entries(this))if(e.category.equals(selected)){
   LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(bg(Color.WHITE,18));
   TextView title=text(e.title+"  ›",21,Color.BLACK);title.setTypeface(null,Typeface.BOLD);card.addView(title);
   TextView content=text(e.message,16,Color.DKGRAY);content.setPadding(0,dp(6),0,dp(8));card.addView(content);
   Button use=button(active!=null&&active.id.equals(e.id)?"✓ 懸浮按鈕使用中":"設為懸浮車訊",()->{Config.active(this,e);render();});card.addView(use);
   card.setOnClickListener(v->editEntry(e));title.setOnClickListener(v->editEntry(e));content.setOnClickListener(v->editEntry(e));
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));body.addView(card,p);
  }
  body.addView(button("＋ 新增車訊按鈕",()->editEntry(null)));
 }
 int categoryColor(String s){if(s.equals("跑車"))return Color.rgb(194,143,195);if(s.equals("長單"))return Color.rgb(221,128,67);if(s.equals("未見"))return Color.rgb(155,118,140);return RED;}
 EditText field(LinearLayout box,String hint,String initial){EditText e=new EditText(this);e.setHint(hint);e.setText(initial);e.setTextSize(17);box.addView(e);return e;}
 void editEntry(Config.Entry old){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(10),dp(22),0);
  TextView info=text("每個按鈕可分別設定名稱與真正發出的車訊。",14,Color.GRAY);form.addView(info);
  EditText title=field(form,"按鈕名稱，例如 5分",old==null?"":old.title);
  EditText message=field(form,"發送內容，例如 9205／深藍／5分",old==null?"":old.message);message.setMinLines(3);message.setGravity(Gravity.TOP);
  List<String> cats=Config.categories(this);if(cats.isEmpty()){cats.add("跑車");Config.saveCategories(this,cats);}Spinner category=new Spinner(this);category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));category.setSelection(Math.max(0,cats.indexOf(old==null?selected:old.category)));form.addView(category);
  AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"新增車訊按鈕":"編輯車訊按鈕").setView(form).setPositiveButton("儲存",null).setNegativeButton("取消",null).setNeutralButton(old==null?"":"刪除",null).create();d.setOnShowListener(v->{
   d.getButton(-1).setOnClickListener(w->{String a=title.getText().toString().trim(),m=message.getText().toString().trim();if(a.isEmpty()||m.isEmpty()){message.setError("請輸入按鈕名稱及車訊");return;}String cat=String.valueOf(category.getSelectedItem());List<Config.Entry> all=Config.entries(this);if(old==null)all.add(new Config.Entry(cat,a,m));else for(Config.Entry e:all)if(e.id.equals(old.id)){e.title=a;e.message=m;e.category=cat;}Config.save(this,all);selected=cat;d.dismiss();render();});
   if(old==null)d.getButton(-3).setVisibility(View.GONE);else d.getButton(-3).setOnClickListener(w->{new AlertDialog.Builder(this).setTitle("刪除這個車訊按鈕？").setPositiveButton("刪除",(x,y)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.id.equals(old.id));Config.save(this,all);d.dismiss();render();}).setNegativeButton("取消",null).show();});
  });d.show();
 }
 void editCategory(String old){EditText input=new EditText(this);input.setHint("分類名稱");input.setText(old==null?"":old);new AlertDialog.Builder(this).setTitle(old==null?"新增分類":"修改分類名稱").setView(input).setPositiveButton("儲存",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;List<String> cats=Config.categories(this);if(cats.contains(name)&&!name.equals(old)){toast("此分類已存在");return;}if(old!=null){int i=cats.indexOf(old);if(i>=0)cats.set(i,name);List<Config.Entry> all=Config.entries(this);for(Config.Entry e:all)if(e.category.equals(old))e.category=name;Config.save(this,all);}else cats.add(name);Config.saveCategories(this,cats);selected=name;render();}).setNegativeButton("取消",null).show();}
 void categoryMenu(String name){new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"修改名稱","刪除分類"},(d,w)->{if(w==0)editCategory(name);else new AlertDialog.Builder(this).setTitle("刪除分類及其中的車訊？").setPositiveButton("刪除",(a,b)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.category.equals(name));Config.save(this,all);List<String> cats=Config.categories(this);cats.remove(name);Config.saveCategories(this,cats);render();}).setNegativeButton("取消",null).show();}).show();}
 void showSettings(){
  body.addView(button("啟用 LINE 懸浮助手",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
  body.addView(button("啟用車訊快捷鍵盤",()->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
  body.addView(button("切換鍵盤",()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));
  TextView help=text("使用方式\n\n① 在『我的鍵盤』設定每個按鈕的車訊。\n② 開啟 LINE 聊天室。\n③ 點懸浮『車訊』，自動取得最新訊息，加上目前車訊後傳送。\n\n懸浮『選擇』可切換要發出的車訊。\n『只發車訊』不擷取對話，直接發送選定車訊。\n『收回』用來收回自己最新可辨識的訊息。\n\n不需校正訊息，也不用手動輸入分類符號。",16,Color.DKGRAY);help.setPadding(dp(10),dp(18),dp(10),dp(20));body.addView(help);
  TextView limit=text("若 LINE 不提供可讀文字，Android 11 以上會自動嘗試螢幕文字辨識。圖片／貼圖不會當成文字訊息。辨識與收回仍需你的 LINE 實測。",14,Color.GRAY);body.addView(limit);
 }
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
