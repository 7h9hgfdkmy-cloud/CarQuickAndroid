package com.carquick.android;

import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 final int RED=Color.rgb(37,99,235), BG=Color.rgb(243,246,252), INK=Color.rgb(16,35,65), MUTED=Color.rgb(100,116,139), SOFT=Color.rgb(234,242,255);
 String selected="跑車";LinearLayout body;int page=0;
 @Override public void onCreate(Bundle b){super.onCreate(b);Membership.get(this);if(!Membership.allowed())page=3;render();}
 @Override protected void onResume(){super.onResume();render();}
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
 GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 LinearLayout card(LinearLayout parent){
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(18),dp(18),dp(18),dp(18));box.setBackground(bg(Color.WHITE,22));
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(14));parent.addView(box,p);return box;
 }
 void heading(LinearLayout parent,String title,String detail){TextView t=text(title,18,INK);t.setTypeface(null,Typeface.BOLD);parent.addView(t);if(!detail.isEmpty()){TextView sub=text(detail,13,MUTED);sub.setPadding(0,dp(5),0,dp(12));sub.setLineSpacing(dp(3),1);parent.addView(sub);}}
 void section(String title,String detail){TextView t=text(title,20,INK);t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(2),dp(10),0,dp(6));body.addView(t);TextView sub=text(detail,13,MUTED);sub.setPadding(dp(2),0,0,dp(14));body.addView(sub);}
 void styleSwitch(Switch toggle){toggle.setTextSize(16);toggle.setTextColor(INK);toggle.setMinHeight(dp(52));toggle.setSwitchPadding(dp(12));}
 void render(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);root.setPadding(dp(20),dp(18),dp(20),dp(10));setContentView(root);
  if(android.os.Build.VERSION.SDK_INT>=35)root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());root.setPadding(dp(20)+bars.left,dp(12)+bars.top,dp(20)+bars.right,dp(10)+bars.bottom);return insets;});
  TextView brand=text("CAR QUICK  /  車訊快捷助手",11,RED);brand.setLetterSpacing(.12f);brand.setTypeface(null,Typeface.BOLD);root.addView(brand);
  TextView header=text(page==0?"我的懸浮面板":(page==1?"車訊快捷鍵盤":(page==3?(BuildMode.TEST_VERSION?"版本資訊":"會員中心"):"偏好設定")),28,INK);header.setTypeface(null,Typeface.BOLD);header.setPadding(0,dp(7),0,dp(4));root.addView(header);
  TextView subtitle=text(page==0?"常用車訊，一鍵就到位。":page==1?"將每一句常用車訊，整理成快捷按鈕。":page==2?"管理權限、鍵盤與使用偏好。":"0.8.3 · 路線預估測試版",13,MUTED);subtitle.setPadding(0,0,0,dp(20));root.addView(subtitle);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(0,0,0,dp(12));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(page==0)showFloating();else if(page==1)showEntries();else if(page==3)showMember();else showSettings();
  LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(5),dp(5),dp(5),dp(5));nav.setBackground(bg(Color.WHITE,22));
  String[] labels={"懸浮面板","快捷鍵盤","設定",BuildMode.TEST_VERSION?"版本":"會員"};String[] icons={"▦","⌨","⚙","ⓘ"};
  for(int i=0;i<4;i++){final int target=i;TextView tab=text(icons[i]+"\n"+labels[i],12,page==i?RED:MUTED);tab.setGravity(Gravity.CENTER);tab.setLineSpacing(dp(3),1);tab.setTypeface(null,page==i?Typeface.BOLD:Typeface.NORMAL);if(page==i)tab.setBackground(bg(SOFT,16));tab.setContentDescription(labels[i]);tab.setOnClickListener(v->{page=target;render();});nav.addView(tab,new LinearLayout.LayoutParams(0,dp(58),1));}root.addView(nav);
 }
 Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(RED);b.setMinHeight(dp(48));b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x222563EB),bg(SOFT,14),null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));b.setLayoutParams(p);b.setOnClickListener(v->action.run());return b;}
 void showEntries(){

  HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);LinearLayout tabs=new LinearLayout(this);sc.addView(tabs);body.addView(sc);
  List<String> cats=Config.categories(this);if(!cats.contains(selected))selected=cats.isEmpty()?"跑車":cats.get(0);
  for(String name:cats){Button b=button(name,()->{selected=name;render();});b.setTextColor(name.equals(selected)?Color.WHITE:INK);b.setBackground(bg(name.equals(selected)?categoryColor(name):Color.WHITE,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(44));p.setMargins(0,0,dp(8),0);tabs.addView(b,p);b.setOnLongClickListener(v->{categoryMenu(name);return true;});}
  body.addView(button("＋ 新增分類",()->editCategory(null)));
  TextView instruction=text("點選車訊可編輯按鈕內容；長按分類可改名。",13,MUTED);instruction.setPadding(0,dp(8),0,dp(12));body.addView(instruction);
  for(Config.Entry e:Config.entries(this))if(e.category.equals(selected)){
   LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(bg(Color.WHITE,18));
   TextView title=text(e.title+"  ›",21,INK);title.setTypeface(null,Typeface.BOLD);card.addView(title);
   TextView content=text(e.message,16,INK);content.setPadding(0,dp(6),0,dp(8));card.addView(content);

   card.setOnClickListener(v->editEntry(e));title.setOnClickListener(v->editEntry(e));content.setOnClickListener(v->editEntry(e));
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));body.addView(card,p);
  }
  body.addView(button("＋ 新增車訊按鈕",()->editEntry(null)));
 }
 int categoryColor(String s){return RED;}
 EditText field(LinearLayout box,String hint,String initial){TextView label=text(hint,13,MUTED);label.setPadding(0,dp(14),0,dp(6));box.addView(label);EditText e=new EditText(this);e.setHint(hint);e.setText(initial);e.setTextSize(16);e.setTextColor(INK);e.setPadding(dp(12),dp(12),dp(12),dp(12));e.setBackground(bg(SOFT,12));box.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 View scrollForm(LinearLayout form){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(form);return scroll;}
 void editEntry(Config.Entry old){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(10),dp(22),0);
  TextView info=text("每個按鈕可分別設定名稱與真正發出的車訊。",14,MUTED);form.addView(info);
  EditText title=field(form,"按鈕名稱，例如 5分",old==null?"":old.title);
  EditText message=field(form,"發送內容，例如 0000/黑",old==null?"0000/黑":old.message);message.setMinLines(3);message.setGravity(Gravity.TOP);
  List<String> cats=Config.categories(this);if(cats.isEmpty()){cats.add("跑車");Config.saveCategories(this,cats);}Spinner category=new Spinner(this);category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));category.setSelection(Math.max(0,cats.indexOf(old==null?selected:old.category)));form.addView(category);
  AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"新增車訊按鈕":"編輯車訊按鈕").setView(scrollForm(form)).setPositiveButton("儲存",null).setNegativeButton("取消",null).setNeutralButton(old==null?"":"刪除",null).create();d.setOnShowListener(v->{
   d.getButton(-1).setOnClickListener(w->{String a=title.getText().toString().trim(),m=message.getText().toString().trim();if(a.isEmpty()||m.isEmpty()){message.setError("請輸入按鈕名稱及車訊");return;}String cat=String.valueOf(category.getSelectedItem());List<Config.Entry> all=Config.entries(this);if(old==null)all.add(new Config.Entry(cat,a,m));else for(Config.Entry e:all)if(e.id.equals(old.id)){e.title=a;e.message=m;e.category=cat;}Config.save(this,all);selected=cat;d.dismiss();render();});
   if(old==null)d.getButton(-3).setVisibility(View.GONE);else d.getButton(-3).setOnClickListener(w->{new AlertDialog.Builder(this).setTitle("刪除這個車訊按鈕？").setPositiveButton("刪除",(x,y)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.id.equals(old.id));Config.save(this,all);d.dismiss();render();}).setNegativeButton("取消",null).show();});
  });d.show();
 }
 void editCategory(String old){EditText input=new EditText(this);input.setHint("分類名稱");input.setText(old==null?"":old);new AlertDialog.Builder(this).setTitle(old==null?"新增分類":"修改分類名稱").setView(input).setPositiveButton("儲存",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;List<String> cats=Config.categories(this);if(cats.contains(name)&&!name.equals(old)){toast("此分類已存在");return;}if(old!=null){int i=cats.indexOf(old);if(i>=0)cats.set(i,name);List<Config.Entry> all=Config.entries(this);for(Config.Entry e:all)if(e.category.equals(old))e.category=name;Config.save(this,all);}else cats.add(name);Config.saveCategories(this,cats);selected=name;render();}).setNegativeButton("取消",null).show();}
 void categoryMenu(String name){new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"修改名稱","刪除分類"},(d,w)->{if(w==0)editCategory(name);else new AlertDialog.Builder(this).setTitle("刪除分類及其中的車訊？").setPositiveButton("刪除",(a,b)->{List<Config.Entry> all=Config.entries(this);all.removeIf(e->e.category.equals(name));Config.save(this,all);List<String> cats=Config.categories(this);cats.remove(name);Config.saveCategories(this,cats);render();}).setNegativeButton("取消",null).show();}).show();}
 void showSettings(){
  permissionControls();
  LinearLayout outer=body;body=card(outer);heading(body,"系統與鍵盤","快速前往手機權限與輸入法設定。");
  body.addView(button(BuildMode.TEST_VERSION?"測試版資訊":"會員登入與使用期限",()->{page=3;render();}));
  body.addView(button("全部車訊套用 0000/黑",()->new AlertDialog.Builder(this).setTitle("將全部車訊改為 0000/黑？").setMessage("會修改所有懸浮按鈕及快捷鍵盤的車訊，保留按鈕名稱。此操作會覆蓋自訂車訊。").setPositiveButton("全部套用",(d,w)->{Config.resetAllMessages(this);render();toast("已全部套用 0000/黑");}).setNegativeButton("取消",null).show()));
  body.addView(button("啟用 LINE 懸浮助手",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
  body.addView(button("啟用車訊快捷鍵盤",()->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
  body.addView(button("切換鍵盤",()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));
  body=outer;body=card(outer);
  TextView help=text("使用方式\n\n① 在『懸浮按鈕』設定需要的按鈕數量。\n② 分別設定每個按鈕的文字及車訊。\n③ 開啟 LINE，點對應按鈕就發送該按鈕的車訊。\n\n每個按鈕可選『最新訊息＋車訊』或『只發車訊』。\n\n直接滑動按鈕或面板空白處，可移動整個面板；放開後位置會儲存。長按車訊按鈕後拖到指定訊息，則會選取該則訊息，加上車訊發送。\n\n可以調整按鈕大小、透明度和每列數量。收回按鈕可另外開關。",16,INK);help.setPadding(dp(10),dp(18),dp(10),dp(20));body.addView(help);
  body.addView(text("最新訊息辨識及 LINE 傳送仍需你的手機實測；請先在測試對話中確認操作結果。",14,MUTED));body=outer;
 }
 void showFloating(){
  LinearLayout hero=card(body);GradientDrawable gradient=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF2563EB,0xFF163D91});gradient.setCornerRadius(dp(22));hero.setBackground(gradient);
  TextView eyebrow=text("QUICK PANEL",11,0xFFBFDBFE);eyebrow.setLetterSpacing(.15f);hero.addView(eyebrow);
  Switch enabled=new Switch(this);styleSwitch(enabled);enabled.setText("開啟懸浮按鈕");enabled.setTextSize(21);enabled.setTextColor(Color.WHITE);enabled.setTypeface(null,Typeface.BOLD);enabled.setChecked(Config.floatingEnabled(this));hero.addView(enabled);
  TextView enabledHint=text("",13,0xFFDBEAFE);enabledHint.setLineSpacing(dp(3),1);hero.addView(enabledHint);
  Runnable status=()->enabledHint.setText(!Config.floatingEnabled(this)?"目前已關閉 · 隨時開啟，快速回覆。":accessibilityEnabled()?"已開啟 · 回到 LINE 即可使用。":"已開啟面板開關 · 請先啟用下方無障礙服務。");status.run();
  enabled.setOnCheckedChangeListener((view,checked)->{Config.prefs(this).edit().putBoolean("floatingEnabled",checked).apply();status.run();});
  TextView count=text(Config.floatingCount(this)+" 個車訊按鈕  /  自訂內容與排列",12,Color.WHITE);count.setPadding(0,dp(18),0,0);hero.addView(count);
  permissionControls();
  section("面板外觀","調整小巧尺寸與透明度，即時查看效果。");
  LinearLayout outer=body,appearance=card(body);body=appearance;
  heading(body,"即時預覽","按鈕名稱與排列會同步顯示在這裡。");
  HorizontalScrollView previewScroll=new HorizontalScrollView(this);previewScroll.setHorizontalScrollBarEnabled(false);
  LinearLayout preview=new LinearLayout(this);preview.setOrientation(1);preview.setPadding(dp(6),dp(6),dp(6),dp(6));preview.setBackground(bg(0xFFDCE9FA,12));previewScroll.addView(preview);body.addView(previewScroll);updatePreview(preview);
  body.addView(button("車訊按鈕數量："+Config.floatingCount(this)+" 個  ›",()->pickNumber("車訊按鈕數量（不含導航及收回）",1,FloatingSpec.MAX_COUNT,Config.floatingCount(this),v->{Config.floatingCount(this,v);render();})));
  body.addView(button("每列排列："+Config.floatingColumns(this)+" 個  ›",()->pickNumber("每列按鈕數量",1,4,Config.floatingColumns(this),v->{Config.prefs(this).edit().putInt("floatingColumns",v).apply();render();})));
  slider("floatingSize","按鈕高度",28,60,Config.floatingSize(this)," dp",preview);
  slider("floatingOpacity","不透明度",20,100,Config.floatingOpacity(this),"%",preview);
  body=outer;
  section("我的車訊按鈕","點選卡片，獨立設定按鈕文字與發送內容。");
  int index=0;for(Config.FloatingButton spec:Config.floating(this)){
   final int number=++index;LinearLayout item=card(body);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);item.addView(row);
   TextView badge=text(String.format(java.util.Locale.ROOT,"%02d",number),14,RED);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,Typeface.BOLD);badge.setBackground(bg(SOFT,12));row.addView(badge,new LinearLayout.LayoutParams(dp(42),dp(42)));
   TextView title=text(spec.title,18,INK);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(12),0,dp(8),0);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));row.addView(text("編輯 ›",12,RED));
   TextView content=text(spec.message.isEmpty()?"尚未設定車訊，點此輸入":spec.message,16,INK);content.setPadding(0,dp(14),0,dp(12));item.addView(content);
   TextView mode=text(spec.append?"最新訊息 ＋ 車訊":"只發送車訊",12,RED);mode.setPadding(dp(10),dp(6),dp(10),dp(6));mode.setBackground(bg(SOFT,8));item.addView(mode,new LinearLayout.LayoutParams(-2,-2));
   item.setContentDescription("編輯按鈕 "+number+"，"+spec.title);item.setOnClickListener(v->editFloating(spec,number));
  }
  section("延伸功能","路線預估先看時間、公里數，再決定開始導航。");body=card(outer);
  Switch navigation=new Switch(this);styleSwitch(navigation);navigation.setText("顯示路線預估按鈕");navigation.setChecked(Config.floatingNavigation(this));navigation.setOnCheckedChangeListener((v,checked)->{Config.prefs(this).edit().putBoolean("floatingNavigation",checked).apply();updatePreview(preview);});body.addView(navigation);
  body.addView(button("導航預設城市："+Config.prefs(this).getString("navigationCity","未設定")+"  ›",()->{EditText input=new EditText(this);input.setHint("例如 高雄市（可留空）");input.setText(Config.prefs(this).getString("navigationCity",""));new AlertDialog.Builder(this).setTitle("導航預設城市").setMessage("地址或店名缺少縣市時，會加上這個城市協助 Google Maps 查詢。").setView(input).setPositiveButton("儲存",(d,w)->{Config.prefs(this).edit().putString("navigationCity",input.getText().toString().trim()).apply();render();}).setNegativeButton("取消",null).show();}));
  Switch undo=new Switch(this);styleSwitch(undo);undo.setText("顯示收回按鈕");undo.setChecked(Config.floatingUndo(this));undo.setOnCheckedChangeListener((v,checked)->{Config.prefs(this).edit().putBoolean("floatingUndo",checked).apply();updatePreview(preview);});body.addView(undo);
  body=outer;LinearLayout tip=card(body);heading(tip,"三種手勢，快速操作","短按：依按鈕設定發送車訊。\n長按後拖到訊息：選取該則訊息，加車訊發送。\n直接滑動：移動整個懸浮面板。");
 }
 interface NumberChoice { void select(int value); }
 void pickNumber(String title,int min,int max,int value,NumberChoice choice){NumberPicker picker=new NumberPicker(this);picker.setMinValue(min);picker.setMaxValue(max);picker.setValue(value);picker.setWrapSelectorWheel(false);new AlertDialog.Builder(this).setTitle(title).setView(picker).setPositiveButton("儲存",(d,w)->choice.select(picker.getValue())).setNegativeButton("取消",null).show();}
 void slider(String key,String title,int min,int max,int value,String unit,LinearLayout preview){
  TextView label=text(title+"："+value+unit,14,INK);label.setPadding(0,dp(10),0,0);body.addView(label);SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(value-min);body.addView(bar);
  bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int progress,boolean fromUser){int v=min+progress;label.setText(title+"："+v+unit);if(fromUser){Config.prefs(MainActivity.this).edit().putInt(key,v).apply();updatePreview(preview);}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
 }
 void updatePreview(LinearLayout grid){
  grid.removeAllViews();grid.setAlpha(Config.floatingOpacity(this)/100f);int size=Config.floatingSize(this),width=FloatingSpec.width(size),columns=Config.floatingColumns(this);int available=getResources().getDisplayMetrics().widthPixels-dp(88);columns=Math.min(columns,Math.max(1,available/dp(width+4)));
  LinearLayout row=null;int index=0;List<String> labels=new ArrayList<>();for(Config.FloatingButton b:Config.floating(this))labels.add(b.title);if(Config.floatingNavigation(this))labels.add("導航");if(Config.floatingUndo(this))labels.add("收回");
  for(String label:labels){if(index++%columns==0){row=new LinearLayout(this);grid.addView(row);}TextView t=text(label,size<36?11:12,INK);t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setEllipsize(android.text.TextUtils.TruncateAt.END);t.setBackground(bg(0xFFDFEBFF,8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(width),dp(size));p.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(t,p);}
 }
 void editFloating(Config.FloatingButton old,int number){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(8),dp(22),0);
  form.addView(text("這個按鈕會直接使用以下車訊發送。",14,MUTED));
  EditText title=field(form,"按鈕上的文字",old.title);EditText message=field(form,"此按鈕要發送的車訊",old.message);message.setMinLines(3);message.setGravity(Gravity.TOP);
  Switch append=new Switch(this);append.setText("加上 LINE 最新訊息");append.setChecked(old.append);form.addView(append);form.addView(text("短按時：開啟為最新訊息＋車訊；關閉為只發車訊。長按拖選時一律為指定訊息＋車訊。",13,MUTED));
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("設定按鈕 "+number).setView(scrollForm(form)).setPositiveButton("儲存",null).setNegativeButton("取消",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String label=title.getText().toString().trim(),content=message.getText().toString().trim();if(label.isEmpty()){title.setError("請輸入按鈕文字");return;}if(content.isEmpty()){message.setError("請輸入車訊");return;}List<Config.FloatingButton> all=Config.allFloating(this);for(Config.FloatingButton b:all)if(b.id.equals(old.id)){b.title=label;b.message=content;b.append=append.isChecked();}Config.saveFloating(this,all);dialog.dismiss();render();}));dialog.show();
 }
 boolean accessibilityEnabled(){
  boolean enabled=false;
  android.view.accessibility.AccessibilityManager manager=(android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
  if(manager!=null)for(android.accessibilityservice.AccessibilityServiceInfo service:manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){
   android.content.pm.ServiceInfo info=service.getResolveInfo().serviceInfo;
   if(getPackageName().equals(info.packageName)&&(getPackageName()+".LineService").equals(info.name))enabled=true;
  }
  return enabled;
 }
 void permissionControls(){
  boolean enabled=accessibilityEnabled();LinearLayout outer=body;body=card(body);
  TextView status=text(enabled?"●  無障礙助手已就緒":"○  完成設定，即可開始使用",14,enabled?Color.rgb(48,131,83):RED);status.setPadding(0,dp(6),0,dp(6));body.addView(status);
  if(!enabled){
   body.addView(button("受限制的設定／App 資訊",()->new AlertDialog.Builder(this).setTitle("允許受限制的設定").setMessage("下一步會開啟本 App 的系統資訊頁。\n\n請點右上角 ⋮ → 允許受限制的設定，依系統提示完成驗證。\n\n完成後回到 App，再開啟無障礙服務。不同手機的選項位置可能不同；這個按鈕不會自動授權。").setPositiveButton("前往 App 資訊",(d,w)->openAppInfo()).setNegativeButton("取消",null).show()));
   body.addView(button("開啟無障礙服務設定",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
  }
  body=outer;
 }
 void openAppInfo(){
  try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName())));}
  catch(android.content.ActivityNotFoundException e){toast("請到手機設定 → 應用程式 → 車訊快捷助手 → App 資訊");}
 }
 void showMember(){
  if(BuildMode.TEST_VERSION){
   LinearLayout version=card(body);heading(version,"Car Quick  0.8.3","路線預估 · Android 測試版");version.addView(text("免登入 · 無月租到期限制",16,RED));
   version.addView(text("可直接測試導航、長按拖選訊息、車訊傳送、收回及快捷鍵盤。無需會員帳號或後台連線，也沒有月租到期限制。",16,INK));
   version.addView(text("預設車訊：0000/黑。請到懸浮按鈕分頁設定各個按鈕的文字及發送內容。",16,MUTED));LinearLayout notes=card(body);heading(notes,"本次更新","導航改為 Google Maps 開車路線預估；支援從訊息讀取店名。多個候選地點可先選擇，店名建議搭配預設城市。");return;
  }
  Membership m=Membership.get(this);TextView status=text(m.status(),20,Membership.allowed()?Color.rgb(48,131,83):RED);status.setTypeface(null,Typeface.BOLD);status.setPadding(0,dp(10),0,dp(12));body.addView(status);
  if(!m.username().isEmpty())body.addView(text("會員帳號："+m.username(),16,INK));
  if(m.expires()>0){java.text.SimpleDateFormat date=new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm",java.util.Locale.TAIWAN);date.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Taipei"));body.addView(text("使用期限："+date.format(new java.util.Date(m.expires()*1000)),16,INK));}
  if(!m.configured()){body.addView(text("會員服務尚未啟用，請聯絡管理員完成啟用後再登入。此版本需有效會員資格才能發送車訊或收回訊息；按鈕設定仍可編輯。",16,INK));return;}
  body.addView(text("使用管理員提供的帳號登入。一個帳號限綁定一支手機；續費或更換手機請聯絡管理員。",15,MUTED));
  EditText name=field(body,"會員帳號",m.username());name.setSingleLine(true);name.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
  EditText password=field(body,"密碼","");password.setSingleLine(true);password.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  TextView result=text("",14,RED);body.addView(result);
  Button login=button("登入",()->{});login.setOnClickListener(v->{String account=name.getText().toString().trim(),secret=password.getText().toString();if(account.isEmpty()||secret.isEmpty()){result.setText("請輸入帳號與密碼");return;}login.setEnabled(false);result.setText("正在登入…");m.login(account,secret,message->{if(isFinishing())return;password.setText("");login.setEnabled(true);result.setText(message);if(!m.username().isEmpty()){render();toast(message);}});});body.addView(login);
  body.addView(button("重新驗證／更新期限",()->{result.setText("正在驗證…");m.refresh(message->{if(!isFinishing()){render();toast(message);}});}));
  if(!m.username().isEmpty())body.addView(button("登出",()->{m.logout();render();}));
  TextView note=text("會員資格在背景定期驗證，操作車訊時不會逐次連網。請保持網路可用；到期或長時間無法驗證時會停用發送與收回。",14,MUTED);note.setPadding(0,dp(16),0,0);body.addView(note);
 }
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
