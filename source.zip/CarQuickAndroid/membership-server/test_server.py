import unittest, tempfile, threading, json, http.client, time, base64
from datetime import datetime
from zoneinfo import ZoneInfo
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from server import create_server, ApiError, add_months

class ServerTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.server=create_server('127.0.0.1',0,cls.tmp.name,'owner','A-test-only-password-123');cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.counter=0
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.server.store.db.close();cls.tmp.cleanup()
 def request(self,path,data=None,cookie='',csrf='',token=''):
  c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5);headers={}
  if cookie:headers['Cookie']=cookie
  if csrf:headers['X-CSRF-Token']=csrf
  if token:headers['Authorization']='Bearer '+token
  if data is not None:headers['Content-Type']='application/json'
  c.request('POST' if data is not None else 'GET',path,json.dumps(data) if data is not None else None,headers);r=c.getresponse();raw=r.read();result=json.loads(raw);status=r.status;cookie=r.getheader('Set-Cookie');c.close();return status,result,cookie
 def admin(self):
  s,r,c=self.request('/admin/login',{'username':'owner','password':'A-test-only-password-123'});self.assertEqual(s,200);return c.split(';')[0],r['csrf']
 def member(self,months=1):
  type(self).counter+=1;name='member'+str(self.counter);uid=self.server.store.manage('test',{'action':'create','username':name,'password':'member-pass-123','months':months});row=self.server.store.db.execute('SELECT * FROM users WHERE username=?',(name,)).fetchone();return name,row['id']
 def login(self,name,device='a'*64):return self.request('/v1/login',{'username':name,'password':'member-pass-123','device':device})
 def claims(self,token):
  h,p,s=token.split('.');pad=lambda x:x+'='*((4-len(x)%4)%4)
  self.server.store.key.public_key().verify(base64.urlsafe_b64decode(pad(s)),(h+'.'+p).encode(),padding.PKCS1v15(),hashes.SHA256());return json.loads(base64.urlsafe_b64decode(pad(p)))
 def test_01_admin_protected(self):
  self.assertEqual(self.request('/admin/members')[0],401);self.assertEqual(self.request('/admin/manage',{'action':'create'})[0],401)
 def test_02_admin_cookie_and_csrf(self):
  cookie,csrf=self.admin();self.assertEqual(self.request('/admin/manage',{'action':'create'},cookie)[0],403)
  self.assertEqual(self.request('/admin/members',cookie=cookie)[0],200)
 def test_03_create_through_admin_api(self):
  cookie,csrf=self.admin();s,r,_=self.request('/admin/manage',{'action':'create','username':'api-created','password':'password-123','months':1},cookie,csrf);self.assertEqual(s,200)
 def test_04_login_signed_active(self):
  name,_=self.member();status,result,_=self.login(name);self.assertEqual(status,200);claims=self.claims(result['license']);self.assertTrue(claims['active']);self.assertEqual(claims['device'],'a'*64);self.assertLessEqual(claims['exp']-claims['iat'],300)
 def test_05_unpaid_inactive(self):
  name,_=self.member(0);status,result,_=self.login(name);self.assertEqual(status,200);self.assertFalse(self.claims(result['license'])['active'])
 def test_06_device_bound(self):
  name,_=self.member();self.assertEqual(self.login(name)[0],200);self.assertEqual(self.login(name,'b'*64)[0],403)
 def test_07_wrong_password_does_not_bind(self):
  name,uid=self.member();self.assertEqual(self.request('/v1/login',{'username':name,'password':'wrong','device':'a'*64})[0],401);self.assertIsNone(self.server.store.db.execute('SELECT device FROM users WHERE id=?',(uid,)).fetchone()['device'])
 def test_08_expiry(self):
  name,uid=self.member();_,result,_=self.login(name);self.server.store.db.execute('UPDATE users SET expires=? WHERE id=?',(int(time.time())-1,uid));s,r,_=self.request('/v1/check',{'device':'a'*64},token=result['session']);self.assertEqual(s,200);self.assertFalse(self.claims(r['license'])['active'])
 def test_09_renewal(self):
  name,uid=self.member(0);_,result,_=self.login(name);self.server.store.manage('owner',{'action':'extend','id':uid,'months':1});s,r,_=self.request('/v1/check',{'device':'a'*64},token=result['session']);self.assertEqual(s,200);self.assertTrue(self.claims(r['license'])['active'])
 def test_10_disable(self):
  name,uid=self.member();_,result,_=self.login(name);self.server.store.manage('owner',{'action':'disable','id':uid});self.assertEqual(self.request('/v1/check',{'device':'a'*64},token=result['session'])[0],401)
 def test_11_unbind(self):
  name,uid=self.member();_,result,_=self.login(name);self.server.store.manage('owner',{'action':'unbind','id':uid});self.assertEqual(self.request('/v1/check',{'device':'a'*64},token=result['session'])[0],401);self.assertEqual(self.login(name,'b'*64)[0],200)
 def test_12_invalid_session(self):self.assertEqual(self.request('/v1/check',{'device':'a'*64},token='fake')[0],401)
 def test_13_logout_revokes(self):
  name,_=self.member();_,result,_=self.login(name);token=result['session'];self.assertEqual(self.request('/v1/logout',{'device':'a'*64},token=token)[0],200);self.assertEqual(self.request('/v1/check',{'device':'a'*64},token=token)[0],401)
 def test_14_password_reset(self):
  name,uid=self.member();_,result,_=self.login(name);self.server.store.manage('owner',{'action':'password','id':uid,'password':'new-password-123'});self.assertEqual(self.request('/v1/check',{'device':'a'*64},token=result['session'])[0],401)
 def test_15_no_password_leak(self):
  self.member();cookie,_=self.admin();s,r,_=self.request('/admin/members',cookie=cookie);self.assertEqual(s,200);self.assertTrue(all('password' not in u for u in r['members']))
 def test_16_month_end(self):
  zone=ZoneInfo('Asia/Taipei');start=int(datetime(2024,1,31,10,tzinfo=zone).timestamp());end=datetime.fromtimestamp(add_months(start,1),zone);self.assertEqual((end.year,end.month,end.day,end.hour),(2024,2,29,10))
 def test_17_duplicate_name(self):
  name,_=self.member()
  with self.assertRaises(ApiError):self.server.store.manage('owner',{'action':'create','username':name,'password':'password-123'})
 def test_18_rate_limit(self):
  store=self.server.store
  with store.lock:
   for _ in range(2):store.limit('test-limit',2)
   with self.assertRaises(ApiError):store.limit('test-limit',2)

if __name__=='__main__':unittest.main()
