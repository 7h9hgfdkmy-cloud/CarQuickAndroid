# 月租會員後台：部署及開通

此資料夾包含可執行的會員 API、管理頁、資料庫、Docker 設定及測試。
沒有預設的客戶帳號，也沒有寫死的管理員密碼。手動確認收款後，在後台開通／續期。
**後台尚未部署，App 的會員服務設定為空。直接編譯此版，只能查看設定，發送與收回會鎖定。**

## 需要的服務
- 一台可持續執行 Docker 的伺服器，或支援 Docker 與永久儲存磁碟的雲端服務。
- 可用的 HTTPS 網址。使用下方 Caddy 設定時，需有指向伺服器的網域，並開放 80／443。
- GitHub Actions 只負責產生 APK，不能代替常駐的會員服務。

## Docker 部署
1. 將此 membership-server 資料夾放到伺服器，安裝 Docker 與 Compose。
2. 複製 `.env.example` 為 `.env`。
3. 設定 MEMBER_DOMAIN、ADMIN_USERNAME、ADMIN_PASSWORD。管理員密碼至少 12 字元，請使用長且不重複的密碼。
4. 執行 `docker compose up -d --build`。
5. 開啟 `https://你的網域/admin`，使用上一步設定的管理員帳號登入。
6. `member_data` 是永久資料，包括帳號、到期日、操作紀錄與簽章私鑰；需要備份，不能刪除，也不能上傳 GitHub。

管理員只在空資料庫第一次啟動時建立。之後修改環境變數不會重設既有密碼。
此版本為單一伺服器 SQLite 設計；不要在沒有共同資料庫的多個副本間輪流派送請求。
Docker／HTTPS 部署尚未在實際網域驗證。Python HTTP 層需位於 HTTPS 反向代理之後，不要直接對外提供 HTTP。

## 連接 APK
部署後執行：
```
docker compose exec api python configure_android.py --url https://你的網域 --key /data/signing.pem --output /tmp/member-config.json
docker compose exec api cat /tmp/member-config.json
```
只會顯示 `api_url` 與 **公開**金鑰；不會輸出簽章私鑰。

在 GitHub repository → Settings → Secrets and variables → Actions，新增：
- MEMBER_API_URL：上面的 HTTPS 網址。
- MEMBER_PUBLIC_KEY：JSON 裡 public_key 的完整字串。

將本 ZIP 內 `.github/workflows/build-apk.yml` 替換倉庫根目錄的同名檔案（只需設定一次）。
之後上傳 source.zip 或手動 Run workflow，即可將公開連線設定編進 APK。
另一種方法：把公開 JSON 放進 `app/src/main/assets/member-config.json` 後重新壓縮；不需要將私鑰放進 App。

## 正式收費前：固定 App 簽署
目前舊 workflow 使用隨機 debug 簽署，不適合長期發給客戶；不同簽署可能無法覆蓋更新，而且會改變 Android 裝置識別。
用 JDK 17 的 keytool 產生正式金鑰（互動輸入密碼，不要把密碼寫在指令中）：
```
keytool -genkeypair -storetype PKCS12 -keystore member-release.p12 -alias carquick -keyalg RSA -keysize 3072 -validity 10000
```
將檔案的 Base64 內容放進 GitHub Secret RELEASE_KEYSTORE_B64，並設定：
- RELEASE_STORE_PASSWORD
- RELEASE_KEY_ALIAS（上例為 carquick）
- RELEASE_KEY_PASSWORD
新 workflow 有這些設定就產生正式簽署 APK，缺少時仍只產生測試 APK。
請離線備份原始金鑰及密碼，不要放進 source.zip 或公開倉庫。金鑰應由你持有；本專案沒有替你產生可公開下載的商用私鑰。

## 日常管理
- 建立會員：指定帳號、密碼和開通月數；0 個月表示尚未開通。
- 確認轉帳後按「續期」，輸入月數和收款備註。
- 有效會員從原到期日延長；已到期會員從現在開始計算。以台灣時區按日曆月份計算，月底取該月最後一天。
- 可停用／啟用、解除手機綁定及重設密碼。
- 換手機前先「換手機」解除舊綁定，再在新手機登入。
- 使用者有短效最長 5 分鐘的簽章使用憑證，平時背景更新，不逐次按鈕連網。停用帳號最遲在短效憑證失效後停用 App，不承諾即時遠端停機。
- 離線超過短效期限會停用操作；重新啟動 App 必須再連線驗證，不以手機時間解鎖。
- 沒有自動扣款；這版為手動開通／續期。沒有送出收費通知或訊息的功能。

## 安全與資料
密碼使用 scrypt 雜湊；登入有頻率限制，會員 session 以雜湊存入伺服器。
管理登入使用 HttpOnly／Secure／SameSite Cookie，管理寫入需 CSRF token。
App session 用 Android Keystore AES-GCM 儲存；使用資格以釘選的 RSA 公開金鑰驗證。
帳號以 Android 裝置識別綁定一支手機。重裝／換簽署可能需管理員重綁。這不是不可破解的 DRM。
管理備註與操作紀錄儲存在後台。後台不接收 LINE 對話、地址或截圖。

## 測試
```
python -m pip install -r requirements.txt
python -m unittest discover -s . -p test_server.py -v
```
測試使用臨時資料夾與假的測試帳號；不包含正式帳密或正式私鑰。
