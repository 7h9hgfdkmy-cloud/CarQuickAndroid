"""Private monthly membership API. Run behind an HTTPS reverse proxy."""
import base64, calendar, hashlib, hmac, json, os, secrets, sqlite3, threading, time
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlsplit
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding

ROOT = Path(__file__).resolve().parent
LEASE_SECONDS = 300

def b64(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def password_hash(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)
    return base64.b64encode(salt).decode() + ':' + base64.b64encode(digest).decode()
def password_ok(password, stored):
    try:
        salt, digest = stored.split(':')
        return hmac.compare_digest(hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=16384, r=8, p=1), base64.b64decode(digest))
    except (ValueError, TypeError): return False

def add_months(epoch, months):
    d = datetime.fromtimestamp(epoch, ZoneInfo('Asia/Taipei'))
    total = d.year * 12 + d.month - 1 + months
    year, month = divmod(total, 12); month += 1
    return int(d.replace(year=year, month=month, day=min(d.day, calendar.monthrange(year, month)[1])).timestamp())

class ApiError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

class Store:
    def __init__(self, directory, admin_username, admin_password):
        directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock(); self.db = sqlite3.connect(directory / 'members.sqlite', check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''PRAGMA journal_mode=WAL;
          CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,admin INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,expires INTEGER NOT NULL DEFAULT 0,device TEXT,created INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL,device TEXT,csrf TEXT);
          CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor TEXT,action TEXT,user_id TEXT,details TEXT,created INTEGER);
          CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY,count INTEGER,until INTEGER);
        ''')
        keyfile = directory / 'signing.pem'
        if not keyfile.exists():
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            fd = os.open(keyfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as out: out.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        self.key = serialization.load_pem_private_key(keyfile.read_bytes(), password=None)
        if not self.db.execute('SELECT 1 FROM users WHERE admin=1').fetchone():
            if not admin_username or len(admin_password or '') < 12: raise ValueError('首次啟動請設定 ADMIN_USERNAME 與至少 12 字元的 ADMIN_PASSWORD。')
            self.db.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?)',(secrets.token_hex(16),admin_username,password_hash(admin_password),1,1,0,None,int(time.time())))
    def public_key(self):
        return base64.b64encode(self.key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode()
    def log(self, actor, action, uid, details=''):
        self.db.execute('INSERT INTO audit(actor,action,user_id,details,created) VALUES(?,?,?,?,?)',(actor,action,uid,details,int(time.time())))
    def limit(self, key, max_count=10):
        now=int(time.time()); row=self.db.execute('SELECT * FROM limits WHERE key=?',(key,)).fetchone()
        if row and row['until']>now and row['count']>=max_count: raise ApiError(429,'嘗試過於頻繁，請一分鐘後重試。')
        count=(row['count']+1) if row and row['until']>now else 1
        until=row['until'] if row and row['until']>now else now+60
        self.db.execute('INSERT OR REPLACE INTO limits VALUES(?,?,?)',(key,count,until))
    def login(self, username, password, device, admin=False, ip='local'):
        if not isinstance(username,str) or not isinstance(password,str) or len(username)>80 or len(password)>256: raise ApiError(400,'帳號或密碼格式不正確。')
        with self.lock:
            self.limit('login:'+ip,30); self.limit('account:'+username,10)
            user=self.db.execute('SELECT * FROM users WHERE username=? AND admin=?',(username,int(admin))).fetchone()
            if user is None or not password_ok(password,user['password']): raise ApiError(401,'帳號或密碼不正確。')
            if not user['enabled']: raise ApiError(403,'帳號已停用，請聯絡管理員。')
            if not admin:
                if not isinstance(device,str) or len(device)!=64 or any(c not in '0123456789abcdef' for c in device): raise ApiError(400,'裝置識別不正確。')
                self.db.execute('BEGIN IMMEDIATE')
                try:
                    current=self.db.execute('SELECT device FROM users WHERE id=?',(user['id'],)).fetchone()['device']
                    if current and current!=device: raise ApiError(403,'此帳號已綁定另一支手機，請管理員解除綁定。')
                    self.db.execute('UPDATE users SET device=? WHERE id=?',(device,user['id'])); self.db.execute('COMMIT')
                except Exception:
                    self.db.execute('ROLLBACK'); raise
            token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(24)
            self.db.execute('INSERT INTO sessions VALUES(?,?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user['id'],int(time.time())+(8*3600 if admin else 30*86400),None if admin else device,csrf))
            return token,csrf,self.db.execute('SELECT * FROM users WHERE id=?',(user['id'],)).fetchone()
    def session(self, token, admin=False, device=None):
        with self.lock:
            digest=hashlib.sha256(token.encode()).hexdigest()
            s=self.db.execute('SELECT s.*,u.username,u.admin,u.enabled,u.expires AS member_expires,u.device AS bound_device FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=?',(digest,)).fetchone()
            if not s or s['expires']<=int(time.time()) or not s['enabled'] or bool(s['admin'])!=admin: raise ApiError(401,'登入已失效，請重新登入。')
            if not admin and (s['device']!=device or s['bound_device']!=device): raise ApiError(403,'裝置綁定已變更，請重新登入。')
            return s
    def license(self, user, device):
        now=int(time.time()); expiry=user['member_expires'] if 'member_expires' in user.keys() else user['expires']
        active=bool(user['enabled']) and expiry>now
        payload={'sub':user['username'],'device':device,'active':active,'iat':now,'exp':min(expiry,now+LEASE_SECONDS) if active else now,'member_exp':expiry}
        head=b64(json.dumps({'alg':'RS256','typ':'JWT'},separators=(',',':')).encode()); body=b64(json.dumps(payload,separators=(',',':')).encode())
        data=(head+'.'+body).encode(); sig=self.key.sign(data,padding.PKCS1v15(),hashes.SHA256())
        return head+'.'+body+'.'+b64(sig)
    def members(self):
        with self.lock: return [dict(r) for r in self.db.execute('SELECT id,username,enabled,expires,device,created FROM users WHERE admin=0 ORDER BY created DESC LIMIT 500')]
    def manage(self, actor, data):
        action=data.get('action'); uid=data.get('id'); note=str(data.get('note',''))[:200]
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                if action=='create':
                    username=data.get('username',''); password=data.get('password',''); months=int(data.get('months',0))
                    if not isinstance(username,str) or not username.strip() or len(username)>80 or not isinstance(password,str) or not 8<=len(password)<=256 or not 0<=months<=24: raise ApiError(400,'帳號必填，密碼至少 8 字元，月數 0～24。')
                    uid=secrets.token_hex(16); now=int(time.time())
                    try:self.db.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?)',(uid,username.strip(),password_hash(password),0,1,add_months(now,months),None,now))
                    except sqlite3.IntegrityError:raise ApiError(400,'帳號已存在。')
                else:
                    user=self.db.execute('SELECT * FROM users WHERE id=? AND admin=0',(uid,)).fetchone()
                    if not user: raise ApiError(404,'找不到會員。')
                    if action=='extend':
                        months=int(data.get('months',1))
                        if not 1<=months<=24:raise ApiError(400,'續期月數需為 1～24。')
                        expiry=add_months(max(user['expires'],int(time.time())),months)
                        self.db.execute('UPDATE users SET expires=?,enabled=1 WHERE id=?',(expiry,uid))
                        note=json.dumps({'months':months,'note':note},ensure_ascii=False)
                    elif action in ('disable','enable'):self.db.execute('UPDATE users SET enabled=? WHERE id=?',(int(action=='enable'),uid))
                    elif action=='unbind':
                        self.db.execute('UPDATE users SET device=NULL WHERE id=?',(uid,));self.db.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
                    elif action=='password':
                        password=data.get('password','')
                        if not isinstance(password,str) or not 8<=len(password)<=256:raise ApiError(400,'密碼至少 8 字元。')
                        self.db.execute('UPDATE users SET password=? WHERE id=?',(password_hash(password),uid));self.db.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
                    else:raise ApiError(400,'操作不正確。')
                self.log(actor,action,uid,note);self.db.execute('COMMIT')
            except Exception:self.db.execute('ROLLBACK');raise
        return {'ok':True}

class Handler(BaseHTTPRequestHandler):
    server_version='CarQuickMembership/1'
    def log_message(self, format, *args): pass
    def reply(self, status, value, headers=None):
        raw=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def data(self):
        size=int(self.headers.get('Content-Length','0'))
        if size<1 or size>8192:raise ApiError(400,'請求內容不正確。')
        if not self.headers.get('Content-Type','').startswith('application/json'):raise ApiError(415,'僅接受 JSON。')
        obj=json.loads(self.rfile.read(size))
        if not isinstance(obj,dict):raise ApiError(400,'請求內容不正確。')
        return obj
    def admin_session(self, mutate=False):
        cookie=SimpleCookie();cookie.load(self.headers.get('Cookie','')); token=cookie['admin_session'].value if 'admin_session' in cookie else ''
        s=self.server.store.session(token,True)
        if mutate and not hmac.compare_digest(s['csrf'],self.headers.get('X-CSRF-Token','')):raise ApiError(403,'請重新登入管理後台。')
        return s
    def do_GET(self):
        try:
            path=urlsplit(self.path).path
            if path=='/health':return self.reply(200,{'ok':True})
            if path=='/admin/me':
                s=self.admin_session();return self.reply(200,{'username':s['username'],'csrf':s['csrf']})
            if path=='/admin/members':self.admin_session();return self.reply(200,{'members':self.server.store.members()})
            if path in ('/','/admin'):
                raw=(ROOT/'public'/'admin.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
            raise ApiError(404,'找不到頁面。')
        except ApiError as e:self.reply(e.status,{'error':e.message})
        except Exception:self.reply(500,{'error':'服務暫時無法使用。'})
    def do_POST(self):
        try:
            path=urlsplit(self.path).path;data=self.data();store=self.server.store
            if path.startswith('/admin/'):
                origin=self.headers.get('Origin'); expected=os.environ.get('PUBLIC_URL','').rstrip('/')
                if origin and expected and origin!=expected:raise ApiError(403,'來源不正確。')
            if path=='/v1/login':
                token,_,user=store.login(data.get('username'),data.get('password'),data.get('device'),ip=self.client_address[0]);return self.reply(200,{'session':token,'license':store.license(user,data['device'])})
            if path=='/v1/check':
                auth=self.headers.get('Authorization',''); token=auth[7:] if auth.startswith('Bearer ') else ''
                user=store.session(token,False,data.get('device'));return self.reply(200,{'license':store.license(user,data['device'])})
            if path=='/v1/logout':
                auth=self.headers.get('Authorization','');token=auth[7:] if auth.startswith('Bearer ') else ''
                store.session(token,False,data.get('device'))
                with store.lock:store.db.execute('DELETE FROM sessions WHERE hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
                return self.reply(200,{'ok':True})
            if path=='/admin/login':
                token,csrf,_=store.login(data.get('username'),data.get('password'),None,True,self.client_address[0]);return self.reply(200,{'csrf':csrf},{'Set-Cookie':'admin_session='+token+'; HttpOnly; Secure; SameSite=Strict; Path=/admin; Max-Age=28800'})
            if path=='/admin/logout':
                s=self.admin_session(True)
                with store.lock:store.db.execute('DELETE FROM sessions WHERE hash=?',(s['hash'],))
                return self.reply(200,{'ok':True},{'Set-Cookie':'admin_session=; HttpOnly; Secure; SameSite=Strict; Path=/admin; Max-Age=0'})
            if path=='/admin/manage':
                s=self.admin_session(True);return self.reply(200,store.manage(s['username'],data))
            raise ApiError(404,'找不到功能。')
        except ApiError as e:self.reply(e.status,{'error':e.message})
        except (ValueError,TypeError,KeyError):self.reply(400,{'error':'請求格式不正確。'})
        except Exception:self.reply(500,{'error':'服務暫時無法使用。'})

def create_server(host='127.0.0.1',port=8080,directory=None,admin_username=None,admin_password=None):
    store=Store(directory or os.environ.get('DATA_DIR','./data'),admin_username or os.environ.get('ADMIN_USERNAME'),admin_password or os.environ.get('ADMIN_PASSWORD'))
    server=ThreadingHTTPServer((host,port),Handler);server.daemon_threads=True;server.store=store;return server

if __name__=='__main__':
    server=create_server(os.environ.get('HOST','0.0.0.0'),int(os.environ.get('PORT','8080')))
    print('Membership service listening; public key is available through configure_android.py.',flush=True)
    server.serve_forever()
