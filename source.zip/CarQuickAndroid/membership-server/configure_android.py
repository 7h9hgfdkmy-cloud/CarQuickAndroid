"""Write only public connection data to Android assets; never copy private keys."""
import argparse,json
from pathlib import Path
from urllib.parse import urlsplit
from cryptography.hazmat.primitives import serialization
import base64
p=argparse.ArgumentParser();p.add_argument('--url',required=True);p.add_argument('--key',default='./data/signing.pem');p.add_argument('--output',default='../app/src/main/assets/member-config.json');a=p.parse_args()
u=urlsplit(a.url)
if u.scheme!='https' or not u.netloc or u.username or u.password or u.query or u.fragment:raise SystemExit('URL must be a clean HTTPS base URL')
key=serialization.load_pem_private_key(Path(a.key).read_bytes(),password=None)
public=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)).decode()
out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps({'api_url':a.url.rstrip('/'),'public_key':public},ensure_ascii=False,indent=2))
print('Android public configuration written:',out)
