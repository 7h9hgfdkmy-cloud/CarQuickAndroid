package com.carquick.android;
import java.security.*;import java.util.Base64;import java.nio.charset.StandardCharsets;import java.nio.file.*;
public class LicenseSignatureTest {
 static String b64(byte[] b){return Base64.getUrlEncoder().withoutPadding().encodeToString(b);}
 public static void main(String[] args)throws Exception{
  KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);KeyPair key=gen.generateKeyPair();String publicKey=Base64.getEncoder().encodeToString(key.getPublic().getEncoded());String payload="{\"device\":\"test\",\"active\":true}";String data=b64("{\"alg\":\"RS256\"}".getBytes(StandardCharsets.UTF_8))+"."+b64(payload.getBytes(StandardCharsets.UTF_8));Signature s=Signature.getInstance("SHA256withRSA");s.initSign(key.getPrivate());s.update(data.getBytes(StandardCharsets.US_ASCII));String jwt=data+"."+b64(s.sign());
  if(!payload.equals(LicenseSignature.payload(jwt,publicKey)))throw new AssertionError();boolean rejected=false;try{LicenseSignature.payload(jwt.replace(jwt.split("\\.")[1],b64("forged".getBytes(StandardCharsets.UTF_8))),publicKey);}catch(GeneralSecurityException e){rejected=true;}if(!rejected)throw new AssertionError();
  if(args.length==2)LicenseSignature.payload(Files.readString(Path.of(args[0])).trim(),Files.readString(Path.of(args[1])).trim());
  System.out.println("License signature / tampering checks passed");
 }
}
