package com.carquick.android;
import java.util.*;
public class DetectorTest {
 static MessageDetector.Node node(String id,String text,int l,int t,int r,int b){MessageDetector.Node n=new MessageDetector.Node();n.id=id;n.text=text;n.box=new MessageDetector.Box(l,t,r,b);return n;}
 static MessageDetector.Node root(){MessageDetector.Node root=node("","",0,0,1080,2000);MessageDetector.Node list=node("chat_list","",0,150,1080,1800);list.kind="androidx.recyclerview.widget.RecyclerView";root.add(list);MessageDetector.Node editor=node("input","輸入訊息",100,1810,920,1900);editor.editable=true;editor.hint=true;root.add(editor);return root;}
 static MessageDetector.Node row(String text,int y,boolean own){MessageDetector.Node r=node("row","",0,y,1080,y+130);r.add(node("sender_name","乘客",70,y,180,y+20));r.add(node("message_text",text,own?260:80,y+25,own?1050:850,y+110));r.add(node("time","08:30",own?170:870,y+95,own?245:1000,y+115));return r;}
 static void equal(String expected,String actual){if(!expected.equals(actual))throw new AssertionError("Expected "+expected+" got "+actual);}
 public static void main(String[] args){
  MessageDetector.Node root=root(),list=root.children.get(0);list.add(row("舊訊息",300,false));list.add(row("新訊息\n第二行",700,true));
  equal("新訊息\n第二行",MessageDetector.latest(root,false).text);
  equal("新訊息\n第二行",MessageDetector.latest(root,true).text);
  list.add(row("後來收到的訊息",1000,false));equal("後來收到的訊息",MessageDetector.latest(root,false).text);equal("新訊息\n第二行",MessageDetector.latest(root,true).text);
  MessageDetector.Node photo=node("message_photo","",0,1250,1080,1500);list.add(photo);if(!MessageDetector.latest(root,false).media)throw new AssertionError("Must not reuse preceding text after photo");
  list.children.remove(photo);MessageDetector.Node date=node("date_separator","今天",400,1300,600,1340);list.add(date);equal("後來收到的訊息",MessageDetector.latest(root,false).text);
  MessageDetector.Node split=node("row","",0,1500,1080,1720);split.add(node("content_text","第一行地址",80,1510,800,1570));split.add(node("content_text","第二行地址",80,1580,800,1650));list.add(split);equal("第一行地址\n第二行地址",MessageDetector.latest(root,false).text);
  MessageDetector.Node noList=root();noList.children.remove(0);noList.add(node("toolbar_title","群組名稱",100,100,900,180));if(MessageDetector.latest(noList,false).readable())throw new AssertionError("Must not guess toolbar as message");
  if(!MessageDetector.editor(root).hint)throw new AssertionError("Hint must stay distinct from draft");
  MessageDetector.Node time=root();time.children.get(0).add(row("08:30",900,true));equal("08:30",MessageDetector.latest(time,false).text);
  System.out.println("8 detector checks passed");
 }
}
