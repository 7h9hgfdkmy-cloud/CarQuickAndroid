package com.carquick.android;
public class GroupPerformanceTest {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 static MessageDetector.Node node(String id,String text){MessageDetector.Node n=new MessageDetector.Node();n.id=id;n.text=text;n.box=new MessageDetector.Box(0,100,500,200);return n;}
 public static void main(String[] args){
  MessageDetector.Node list=node("chat_list",""),row=node("row","訊息 已讀 1"),body=node("message_text","上車地址"),read=node("read_count","已讀 1"),sender=node("sender_name","小王");list.add(row);row.add(body).add(read).add(sender);
  String first=MessageDetector.scrollFingerprint(list);read.text="已讀 99";row.text="訊息 已讀 99";sender.text="小李";check(first.equals(MessageDetector.scrollFingerprint(list)));
  body.text="新的上車地址";String next=MessageDetector.scrollFingerprint(list);check(!first.equals(next));
  body.box.top+=20;check(!next.equals(MessageDetector.scrollFingerprint(list)));
  body.text="12:30";next=MessageDetector.scrollFingerprint(list);body.text="12:31";check(!next.equals(MessageDetector.scrollFingerprint(list)));
  MessageDetector.Node image=node("message_image","");row.add(image);next=MessageDetector.scrollFingerprint(list);image.box.bottom+=50;check(!next.equals(MessageDetector.scrollFingerprint(list)));
  check(MessageDetector.metadataText("已讀 100"));check(MessageDetector.metadataText("下午 12:31"));check(MessageDetector.metadataId("a/read_count"));
  System.out.println("8 group scroll / metadata checks passed");
 }
}
