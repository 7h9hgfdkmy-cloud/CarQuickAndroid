package android.view.accessibility;
import android.graphics.Rect;
import java.util.*;
/** Test fixture only: counts child queries, no Android runtime emulation. */
public class AccessibilityNodeInfo {
 public static int childQueries;public String id="",text="",description="",kind="android.widget.FrameLayout";
 public boolean editable;public List<AccessibilityNodeInfo> children=new ArrayList<>();
 public String getViewIdResourceName(){return id;}public String getText(){return text;}public String getContentDescription(){return description;}public String getClassName(){return kind;}
 public boolean isVisibleToUser(){return true;}public boolean isEditable(){return editable;}public boolean isShowingHintText(){return false;}public boolean isClickable(){return false;}public boolean isLongClickable(){return false;}public boolean isScrollable(){return false;}
 public void getBoundsInScreen(Rect r){r.left=0;r.top=0;r.right=1080;r.bottom=100;}
 public int getChildCount(){return children.size();}public AccessibilityNodeInfo getChild(int i){childQueries++;return children.get(i);}
}
