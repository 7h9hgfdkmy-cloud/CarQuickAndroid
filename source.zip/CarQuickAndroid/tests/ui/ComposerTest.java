package com.carquick.android;
import android.view.accessibility.AccessibilityNodeInfo;
public class ComposerTest {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 static AccessibilityNodeInfo node(String kind,String text){AccessibilityNodeInfo n=new AccessibilityNodeInfo();n.kind=kind;n.text=text;return n;}
 public static void main(String[] args){
  AccessibilityNodeInfo root=node("FrameLayout",""),list=node("androidx.recyclerview.widget.RecyclerView",""),edit=node("EditText","草稿");edit.editable=true;root.children.add(list);root.children.add(edit);
  for(int i=0;i<200;i++){AccessibilityNodeInfo row=node("FrameLayout","");list.children.add(row);for(int j=0;j<10;j++)row.children.add(node("TextView","訊息"+i+"成員"+j));}
  AccessibilityNodeInfo.childQueries=0;UiTree.read(root);int full=AccessibilityNodeInfo.childQueries;
  AccessibilityNodeInfo.childQueries=0;MessageDetector.Node composer=UiTree.composer(root);int small=AccessibilityNodeInfo.childQueries;
  check(MessageDetector.editor(composer).text.equals("草稿"));check(small<full/100);check(full>2000);
  edit.text="更新後的草稿";check(MessageDetector.editor(UiTree.composer(root)).text.equals("更新後的草稿"));
  root.children.remove(edit);list.children.clear();list.children.add(edit);check(MessageDetector.editor(UiTree.composer(root)).text.equals("更新後的草稿"));
  check(UiTree.composer(null)==null);
  AccessibilityNodeInfo other=node("FrameLayout","");check(MessageDetector.editor(UiTree.composer(other))==null);
  System.out.println("7 composer checks passed; synthetic group child queries: "+full+" -> "+small+" (not device latency)");
 }
}
