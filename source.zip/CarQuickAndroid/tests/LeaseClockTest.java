package com.carquick.android;
public class LeaseClockTest {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args){LeaseClock c=new LeaseClock();check(!c.valid(100));check(c.grant(1000,100000,100300,true));check(c.valid(300999));check(!c.valid(301000));check(c.remaining(301001)==0);check(!c.grant(1000,10,311,true));check(!c.grant(1000,10,11,false));check(!c.grant(1000,10,10,true));check(c.grant(1000,10,12,true));c.clear();check(!c.valid(1001));System.out.println("10 membership lease checks passed");}
}
