package com.carquick.android;
public class OverlayVisibilityTest {
 static void check(boolean value,String label){if(!value)throw new AssertionError(label);}
 public static void main(String[] args){
  OverlayVisibility v=new OverlayVisibility();
  check(!v.update(OverlayVisibility.Foreground.UNKNOWN,0),"No initial window must stay hidden");
  check(v.update(OverlayVisibility.Foreground.LINE,10),"LINE opens immediately");
  check(v.update(OverlayVisibility.Foreground.UNKNOWN,100),"Group switch null root keeps overlay");
  check(v.update(OverlayVisibility.Foreground.UNKNOWN,700),"Transition does not blink");
  check(v.update(OverlayVisibility.Foreground.LINE,850)&&!v.waiting(),"New group cancels pending hide");
  check(!v.update(OverlayVisibility.Foreground.OTHER,900),"Actual other app hides immediately");
  check(!v.update(OverlayVisibility.Foreground.UNKNOWN,950),"Unknown after leaving LINE stays hidden");
  check(v.update(OverlayVisibility.Foreground.LINE,1000),"Return to LINE shows immediately");
  check(v.update(OverlayVisibility.Foreground.UNKNOWN,1100),"New transition retains panel");
  check(!v.update(OverlayVisibility.Foreground.UNKNOWN,2300),"Unresolved window eventually hides");
  check(!v.update(OverlayVisibility.Foreground.LINE,2400,false),"Off hides even in LINE");
  check(!v.update(OverlayVisibility.Foreground.UNKNOWN,2450,false)&&!v.waiting(),"Off cancels transition timer");
  check(v.update(OverlayVisibility.Foreground.LINE,2500,true),"On restores LINE panel");
  System.out.println("13 overlay visibility checks passed");
 }
}
