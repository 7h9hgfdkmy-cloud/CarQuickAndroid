package com.carquick.android;
public class FloatingSpecTest {
 static void check(boolean value,String label){if(!value)throw new AssertionError(label);}
 public static void main(String[] args){
  check(FloatingSpec.DEFAULT_COUNT==5,"Default five independent buttons");
  check(FloatingSpec.count(-1)==1&&FloatingSpec.count(30)==20,"Bound count");
  check(FloatingSpec.opacity(55)==55&&FloatingSpec.opacity(0)==20,"Opacity defaults and bounds");
  check(FloatingSpec.width(36)==67&&FloatingSpec.size(36)==36,"Compact dimensions");
  check(!FloatingSpec.moved(3,4,8),"Tap jitter must not drag");
  check(FloatingSpec.moved(9,0,8),"Real drag must cancel button tap");
  check(!FloatingSpec.moved(8,0,8),"Slop threshold is strict");
  check(FloatingSpec.columns(0)==1&&FloatingSpec.columns(9)==4,"Grid bounds");
  System.out.println("8 floating layout/touch checks passed");
 }
}
