package com.carquick.android;
import java.util.*;
public class NavigationPickTest {
 static void equal(Object a,Object b){if(!a.equals(b))throw new AssertionError("Expected "+a+" got "+b);}
 static MessageDetector.Node node(String id,String text,int l,int t,int r,int b){MessageDetector.Node n=new MessageDetector.Node();n.id=id;n.text=text;n.box=new MessageDetector.Box(l,t,r,b);return n;}
 public static void main(String[] args){
  equal(Arrays.asList("高雄市仁武區八卦里京吉二路171號"),AddressExtractor.extract("上:814高雄市仁武區八卦里京吉\n二路171號\n備註:快車\n0000/黑"));
  equal(Arrays.asList("中華四路365巷5號"),AddressExtractor.extract("8:30\n中華四路365巷5號\n0000/黑"));
  equal(Arrays.asList("鳥松區名山二街12號"),AddressExtractor.extract("上:833鳥松區名山二街12號"));
  equal(2,AddressExtractor.extract("上:高雄市苓雅區中正一路1號\n下:高雄市三民區建國二路2號").size());
  equal(Collections.emptyList(),AddressExtractor.extract("0000/黑/5分\n已到，未見乘客"));
  equal("高雄市中華四路1號",AddressExtractor.withCity("中華四路1號","高雄市"));
  equal("臺北市中正區忠孝東路1號",AddressExtractor.withCity("臺北市中正區忠孝東路1號","高雄市"));
  MessageDetector.Node root=node("","",0,0,1080,2000),list=node("chat_list","",0,150,1080,1800);list.kind="androidx.recyclerview.widget.RecyclerView";root.add(list);MessageDetector.Node editor=node("input","",100,1810,920,1900);editor.editable=true;root.add(editor);
  MessageDetector.Node first=node("row","",0,300,1080,450);first.add(node("message_text","指定的舊訊息",80,330,800,420));first.add(node("time","08:30",880,370,1000,400));list.add(first);
  MessageDetector.Node second=node("row","",0,600,1080,750);second.add(node("message_text","最新訊息",260,630,1050,720));list.add(second);
  equal("指定的舊訊息",MessagePick.at(root,200,370,8).text);equal("最新訊息",MessageDetector.latest(root,false).text);
  if(MessagePick.at(root,950,380,8)!=null)throw new AssertionError("Timestamp must not select a message");
  if(MessagePick.at(root,200,520,8)!=null)throw new AssertionError("Blank space cancels selection");
  MessageDetector.Node split=node("row","",0,900,1080,1130);split.add(node("message_text","第一行",80,920,800,980));split.add(node("message_text","第二行",80,990,800,1050));list.add(split);
  equal("第一行\n第二行",MessagePick.at(root,200,1020,8).text);
  System.out.println("12 navigation / message-pick checks passed");
 }
}
