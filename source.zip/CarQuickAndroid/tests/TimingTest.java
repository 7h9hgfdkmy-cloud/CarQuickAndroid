package com.carquick.android;
public class TimingTest {
 static void check(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  check(Timing.endIndex(100,99,1));check(!Timing.endIndex(100,98,1));check(!Timing.endIndex(0,0,1));check(!Timing.endIndex(100,-1,1));
  check(Timing.retryDelay(0)==40);check(Timing.retryDelay(6)==80);
  int total=0;for(int i=0;i<19;i++)total+=Timing.retryDelay(i);check(total>=1100&&total<=1500);
  System.out.println("7 timing checks passed");
 }
}
