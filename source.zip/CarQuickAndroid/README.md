# 車訊快捷助手 Android 0.3 — 多按鈕懸浮面板

## 本次修改
- 取消一個車訊按鈕加「選擇」的方式，改成多個獨立車訊按鈕，同時顯示。
- 預設 5 個，可在 App 設定 1～20 個。每個按鈕各自設定顯示文字及發送車訊。
- 每個按鈕可選「最新訊息＋車訊」或「只發車訊」。
- 預設高度 36dp、寬度約 67dp，比舊版小；高度可調 28～60dp。
- 預設不透明度 55%（半透明），可調 20～100%。
- 每列數量可設 1～4 個；實際顯示會依螢幕寬度調整。
- 移除底部的拖移／狀態框。在任一按鈕或面板空白處滑動，都會拖動整個面板。
- 超過系統的滑動門檻會取消子按鈕點擊，拖移不會發送車訊。
- 位置會儲存，更新按鈕設定後面板會自動重新載入。
- 保留「收回」功能，另外有開關；設定的車訊按鈕數量不包含收回按鈕。
- 減少按鈕數量只會隱藏後面的按鈕，不刪除它們的文字與車訊。增加回去會恢復設定。
- 原有快捷鍵盤保留在另一個分頁，懸浮按鈕的設定獨立管理。

## GitHub 更新：直接上傳 ZIP
你已經改用 ZIP 編譯 workflow：
1. 下載本次提供的 source.zip，不要解壓縮，也不用改名。
2. 回 GitHub 倉庫根目錄（不是 CarQuickAndroid 子資料夾）。
3. Add file → Upload files，上傳 source.zip 覆蓋原檔案，Commit changes。
4. Actions 編譯成功後，下載 car-quick-android-test-apk，解壓縮取得 APK。
5. 如果還沒套用 ZIP workflow，需要先使用前一次提供的 build-apk.yml 替換根目錄 .github/workflows/build-apk.yml。

## 手機使用
1. 安裝新版 APK。若因 GitHub 不同 runner 的 debug 簽署不同而無法更新，先移除舊版；這會清除設定。
2. 無障礙助手關閉再開啟，重新載入服務。
3. App 預設開啟「懸浮按鈕」分頁。
4. 點「車訊按鈕數量」選擇要幾個，例：5 個。
5. 點「1. 按鈕名稱」卡片，設定此按鈕的文字與車訊；依序設定其他按鈕。
6. 「加上 LINE 最新訊息」開啟時，按鈕會擷取最新文字、加上本按鈕車訊並傳送；關閉時只發送本按鈕車訊。
7. 在同一頁可以預覽外觀、調大小、半透明程度、每列按鈕數量及收回開關。
8. 開啟 LINE，點任一按鈕直接操作該按鈕的車訊。按住滑動則移動面板，沒有底部拖移框。

## 驗證範圍
- 8 項訊息偵測檢查通過。
- 8 項懸浮數量、尺寸、透明度及滑動門檻的純 Java 檢查通過。
- 全部 Java 語法解析與 XML／ZIP 檢查通過。
- 此環境沒有 Android SDK，尚未完整編譯 APK；需要 GitHub Actions 驗證 Android 編譯。
- 尚未在你的 Android LINE 實機驗證，不能保證發送、收回及拖移已在你的手機通過。

## 沿用的相容性限制
自動讀取訊息、傳送和收回邏輯沿用 0.2。這次調整不代表已解決所有 LINE 版本的相容性。
有讀取不到的畫面仍會停止；Android 11 以上可對已定位的訊息列嘗試內建中文 OCR。
最新訊息若是圖片／貼圖／語音，不會擷取前一則文字。收回依自己訊息位於右側的標準畫面辨識，不按刪除。
沒有把截圖或對話上傳伺服器的程式碼，也不儲存聊天截圖或記錄。

## JDK 17 測試
```
javac -d checks app/src/main/java/com/carquick/android/MessageDetector.java app/src/main/java/com/carquick/android/FloatingSpec.java tests/*.java
java -cp checks com.carquick.android.DetectorTest
java -cp checks com.carquick.android.FloatingSpecTest
```
